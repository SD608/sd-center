"use strict";

const path = require("node:path");
const { spawn } = require("node:child_process");
const {
  app,
  BrowserWindow,
  dialog,
  ipcMain,
  session,
} = require("electron");

const { SettingsStore } = require("./src/settings");
const { createSpinResult, SYMBOLS } = require("./src/slot-engine");
const { SdLinkGameClient } = require("./src/sdlink-game-client");
const {
  autoFindWalletDatabase,
  beginSpin,
  getAccount,
  getRecentTransactions,
  listAccounts,
  settleRound,
  validateWalletDatabase,
} = require("./src/wallet-database");

const hasLock = app.requestSingleInstanceLock();
if (!hasLock) app.quit();

let mainWindow = null;
let settingsStore = null;
let onlineGameClient = null;
const pendingOnlineSpins = new Map();
const ONLINE_ACCOUNT_ID = "sd-online";

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1320,
    height: 920,
    minWidth: 1020,
    minHeight: 760,
    title: "SD슬롯",
    backgroundColor: "#07090f",
    autoHideMenuBar: true,
    show: false,
    icon: path.join(__dirname, "public", "icons", "icon-512.png"),
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
      devTools: false,
    },
  });

  mainWindow.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
  mainWindow.webContents.on("will-attach-webview", (event) => event.preventDefault());
  mainWindow.webContents.on("will-navigate", (event, url) => {
    try {
      if (new URL(url).protocol !== "file:") event.preventDefault();
    } catch {
      event.preventDefault();
    }
  });
  mainWindow.once("ready-to-show", () => mainWindow.show());
  mainWindow.on("closed", () => { mainWindow = null; });
  mainWindow.loadFile(path.join(__dirname, "public", "index.html"));
}

function walletPath() {
  return settingsStore.get().walletDatabasePath;
}

function openCenter() {
  const executable = process.env.SD_CENTER_EXECUTABLE;
  const root = process.env.SD_CENTER_ROOT;
  if (!executable) return { ok: false, error: "종합센터 실행 정보를 찾지 못했습니다." };

  const args = app.isPackaged || !root ? [] : [root];
  const environment = { ...process.env };
  delete environment.ELECTRON_RUN_AS_NODE;
  delete environment.SD_CENTER_CHILD_ID;
  delete environment.SD_CENTER_MANAGED;

  const child = spawn(executable, args, {
    env: environment,
    detached: true,
    stdio: "ignore",
    windowsHide: false,
  });
  child.unref();
  return { ok: true };
}

function registerIpc() {
  ipcMain.handle("slot:get-bootstrap", () => ({
    settings: settingsStore.get(),
    symbols: SYMBOLS,
  }));

  ipcMain.handle("slot:save-settings", (event, patch) => settingsStore.update(patch));

  ipcMain.handle("wallet:auto-detect", async () => {
    try {
      await onlineGameClient.state();
      settingsStore.update({ walletDatabasePath: "SD Link Online", selectedAccountId: ONLINE_ACCOUNT_ID });
      return { found: true, path: "SD Link Online" };
    } catch (error) {
      return { found: false, error: error.message };
    }
  });

  ipcMain.handle("wallet:choose-database", async () => {
    try {
      await onlineGameClient.state();
      settingsStore.update({ walletDatabasePath: "SD Link Online", selectedAccountId: ONLINE_ACCOUNT_ID });
      return { canceled: false, ok: true, path: "SD Link Online" };
    } catch (error) {
      return { canceled: false, ok: false, error: error.message };
    }
  });

  ipcMain.handle("wallet:list-accounts", async () => {
    try {
      const state = await onlineGameClient.state();
      settingsStore.update({ walletDatabasePath: "SD Link Online", selectedAccountId: ONLINE_ACCOUNT_ID });
      return { connected: true, databasePath: "SD Link Online", accounts: [state.account] };
    } catch (error) {
      return { connected: false, databasePath: "SD Link Online", accounts: [], error: error.message };
    }
  });

  ipcMain.handle("wallet:get-account", async () => {
    try {
      const state = await onlineGameClient.state();
      return {
        connected: true,
        account: state.account,
        transactions: state.normalizedTransactions,
      };
    } catch (error) {
      return { connected: false, account: null, transactions: [], error: error.message };
    }
  });

  ipcMain.handle("slot:start", async (event, payload) => {
    const betAmount = Math.trunc(Number(payload?.betAmount));
    if (!Number.isSafeInteger(betAmount) || betAmount < 100) {
      return { ok: false, error: "베팅금은 100원 이상의 정수로 입력하세요." };
    }

    try {
      const data = await onlineGameClient.rpc("play_sd_slot", {
        p_wager: betAmount,
        p_request_id: onlineGameClient.uuid(),
        p_platform: "windows",
      });
      const roundId = String(data?.round_id || "");
      if (!roundId) throw new Error("온라인 슬롯 라운드 번호를 받지 못했습니다.");
      const wager = Math.trunc(Number(data?.wager || betAmount));
      const balanceBefore = Math.trunc(Number(data?.balance_before || 0));
      const balanceAfter = Math.trunc(Number(data?.balance_after || 0));
      pendingOnlineSpins.set(roundId, { balance: balanceAfter });
      settingsStore.update({
        walletDatabasePath: "SD Link Online",
        selectedAccountId: ONLINE_ACCOUNT_ID,
        betAmount: wager,
      });
      return {
        ok: true,
        roll: Number(data?.roll || 0),
        resultKey: String(data?.result_key || "miss"),
        resultName: String(data?.result_name || "꽝"),
        probability: String(data?.probability || ""),
        multiplier: Number(data?.multiplier || 0),
        stake: wager,
        payout: Math.trunc(Number(data?.payout || 0)),
        reels: Array.isArray(data?.reels) ? data.reels.map(String) : [],
        won: Boolean(data?.won),
        jackpot: Boolean(data?.jackpot),
        roundId,
        balanceAfterBet: balanceBefore - wager,
      };
    } catch (error) {
      return { ok: false, error: error.message };
    }
  });

  ipcMain.handle("slot:settle", async (event, roundId) => {
    const key = String(roundId || "");
    try {
      const cached = pendingOnlineSpins.get(key);
      pendingOnlineSpins.delete(key);
      if (cached) return { ok: true, balance: cached.balance };
      const state = await onlineGameClient.state();
      return { ok: true, balance: state.account.balance };
    } catch (error) {
      return { ok: false, error: error.message };
    }
  });

  ipcMain.handle("center:open", () => {
    try { return openCenter(); }
    catch (error) { return { ok: false, error: error.message }; }
  });
}

app.whenReady().then(() => {
  settingsStore = new SettingsStore(path.join(app.getPath("userData"), "settings.json"));
  onlineGameClient = new SdLinkGameClient();
  settingsStore.update({ walletDatabasePath: "SD Link Online", selectedAccountId: ONLINE_ACCOUNT_ID });
  registerIpc();
  session.defaultSession.setPermissionRequestHandler((webContents, permission, callback) => callback(false));
  createWindow();
});

app.on("second-instance", () => {
  if (!mainWindow) return;
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
});

app.on("window-all-closed", () => app.quit());
