# SD 물류센터 · Season 0 Desktop v1.0.1

SD종합센터의 `앱 추가`로 설치하고 종합센터에서 실행하는 확장팩입니다.

- 홈페이지에서 게임을 실행하지 않습니다.
- SD지갑 `sdwallet.sqlite`를 직접 연결합니다.
- 차량 구매/판매, 본부 승급, 기사 채용, 배송·기사 수익이 같은 SD지갑 거래내역에 기록됩니다.
- SD Link가 같은 지갑을 연결 중이면 기존 로컬 거래 동기화 흐름에서 새 거래를 감지할 수 있습니다.

설치: SD종합센터 → 앱 추가 → SDLogisticsCenter_Season0_Desktop.zip


## v1.0.1 긴급 수정
- 인터페이스 CSS가 로드되지 않던 파일명 불일치 수정
- index.html: styles.css
- 실제 파일: styles.css
- 시작 시 SD지갑 연결 UI와 기존 물류 UI가 정상 스타일로 표시됨
