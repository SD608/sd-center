"use strict";
const path=require("node:path");
module.exports={
  packagerConfig:{asar:true,executableName:"SDLogisticsCenter",icon:path.join(__dirname,"public","icons","icon")},
  rebuildConfig:{},
  makers:[{name:"@electron-forge/maker-squirrel",config:{name:"sdlogisticscenter",setupExe:"SDLogisticsCenter-Setup.exe",setupIcon:path.join(__dirname,"public","icons","icon.ico")}}]
};
