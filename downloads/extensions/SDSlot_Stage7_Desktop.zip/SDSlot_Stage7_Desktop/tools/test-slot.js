"use strict";

const assert = require("node:assert/strict");
const fs = require("node:fs");
const os = require("node:os");
const path = require("node:path");
const crypto = require("node:crypto");
const { DatabaseSync } = require("node:sqlite");
const { createSpinResult, resultForRoll, SYMBOLS } = require("../src/slot-engine");
const { beginSpin, getAccount, settleRound } = require("../src/wallet-database");

const boundaries = [
  [1, "miss"], [75000, "miss"], [75001, "stone"], [87000, "stone"],
  [87001, "coal"], [93000, "coal"], [93001, "copper"], [96500, "copper"],
  [96501, "iron"], [98500, "iron"], [98501, "gold"], [99500, "gold"],
  [99501, "emerald"], [99850, "emerald"], [99851, "diamond"], [99950, "diamond"],
  [99951, "seven"], [99990, "seven"], [99991, "red-seven"], [99999, "red-seven"],
  [100000, "gold-seven"],
];
for (const [roll, expected] of boundaries) assert.equal(resultForRoll(roll).key, expected);

assert.equal(SYMBOLS.reduce((sum, item) => sum + (item.to - item.from + 1), 0), 100000);
const rtp = SYMBOLS.reduce((sum, item) => sum + ((item.to - item.from + 1) / 100000) * item.multiplier, 0);
assert.equal(rtp, 0.75);

const miss = createSpinResult(1000, 1);
assert.equal(miss.payout, 0);
assert.equal(new Set(miss.reels).size === 1, false);
const jackpot = createSpinResult(1000, 100000);
assert.deepEqual(jackpot.reels, ["gold-seven", "gold-seven", "gold-seven"]);
assert.equal(jackpot.payout, 500000);

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), "sdslot-test-"));
const dbPath = path.join(tmp, "wallet.sqlite");
const db = new DatabaseSync(dbPath);
db.exec(`
  PRAGMA foreign_keys=ON;
  CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT NOT NULL, password_hash TEXT NOT NULL, created_at TEXT NOT NULL);
  CREATE TABLE accounts (
    id TEXT PRIMARY KEY, user_id INTEGER NOT NULL, bank_name TEXT NOT NULL,
    account_number TEXT NOT NULL, owner_name TEXT NOT NULL,
    balance INTEGER NOT NULL CHECK(balance >= 0), created_at TEXT NOT NULL, updated_at TEXT NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
  );
  CREATE TABLE transactions (
    id TEXT PRIMARY KEY, account_id TEXT NOT NULL,
    transaction_type TEXT NOT NULL CHECK(transaction_type IN ('deposit','withdraw')),
    amount INTEGER NOT NULL CHECK(amount > 0), memo TEXT NOT NULL, created_at TEXT NOT NULL,
    FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE
  );
`);
const now = new Date().toISOString();
db.prepare("INSERT INTO users VALUES (1,'tester','x',?)").run(now);
db.prepare("INSERT INTO accounts VALUES (?,?,?,?,?,?,?,?)").run(
  "account-1", 1, "SD은행", "100-000", "테스터", 1000000, now, now,
);
db.close();

const spin = createSpinResult(1000, 99991);
const started = beginSpin({ databasePath: dbPath, accountId: "account-1", spin });
assert.equal(started.balance, 999000);
const settled = settleRound({ databasePath: dbPath, roundId: started.roundId });
assert.equal(settled.payout, 250000);
assert.equal(settled.balance, 1249000);
assert.equal(getAccount(dbPath, "account-1").balance, 1249000);
const duplicate = settleRound({ databasePath: dbPath, roundId: started.roundId });
assert.equal(duplicate.alreadySettled, true);
assert.equal(duplicate.balance, 1249000);


const uiHtml = fs.readFileSync(path.join(__dirname, "..", "public", "index.html"), "utf8");
const uiJs = fs.readFileSync(path.join(__dirname, "..", "public", "js", "app.js"), "utf8");
assert.match(uiHtml, /data-action="reset"/);
assert.doesNotMatch(uiHtml, /data-bet="100">\+100</);
assert.doesNotMatch(uiHtml, /data-bet="500">\+500</);
assert.match(uiHtml, /data-bet="100000">\+100,000</);
assert.match(uiHtml, /data-bet="1000000"[^>]*>\+1,000,000</);
assert.match(uiJs, /const REEL_STOP_INTERVAL_MS = 800/);
assert.match(uiJs, /}, 72\);/);
assert.match(uiJs, /increment === 1_000_000/);
assert.match(uiJs, /setBet\(state\.account\.balance\)/);
assert.match(uiJs, /event\.key !== "F5"/);
assert.match(uiJs, /const nextBet = parseBet\(\) \+ increment/);
assert.match(uiJs, /setBet\(1000\)/);

fs.rmSync(tmp, { recursive: true, force: true });
console.log("Slot boundaries, RTP, prepayment and settlement tests OK");
