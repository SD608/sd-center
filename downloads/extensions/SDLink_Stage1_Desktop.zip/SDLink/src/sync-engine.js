"use strict";

const path = require("node:path");
const {
  applyRemoteTransaction,
  backupDatabase,
  fingerprintAccount,
  getAccount,
  listTransactionIds,
  listTransactions,
  recordSyntheticTransaction,
  setAccountBalance,
  signedAmount,
  updateBalanceOnly,
} = require("./wallet-db");

function unwrapJson(value) {
  if (Array.isArray(value) && value.length === 1 && typeof value[0] === "object") {
    return value[0];
  }
  return value;
}

function asNumber(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function safeMetadata(value) {
  if (!value || typeof value !== "object" || Array.isArray(value)) return {};
  return value;
}

class SyncEngine {
  constructor({ authService, configStore, syncState, userDataDirectory, onStatus }) {
    this.auth = authService;
    this.configStore = configStore;
    this.syncState = syncState;
    this.backupDirectory = path.join(userDataDirectory, "sdlink", "backups");
    this.onStatus = typeof onStatus === "function" ? onStatus : () => {};
    this.running = false;
  }

  status(message, kind = "info") {
    this.onStatus({ message, kind, at: new Date().toISOString() });
  }

  requireLocalConfig() {
    const config = this.configStore.load();
    if (!config.databasePath || !config.selectedAccountId) {
      throw new Error("먼저 로컬 SD지갑 데이터베이스와 계좌를 선택하세요.");
    }
    return config;
  }

  async registerDevice() {
    const config = this.requireLocalConfig();
    const account = getAccount(config.databasePath, config.selectedAccountId);
    const fingerprint = fingerprintAccount(account);
    const response = unwrapJson(await this.auth.rpc("register_sd_link_device", {
      p_device_key: config.deviceKey,
      p_device_name: config.deviceName,
      p_wallet_fingerprint: fingerprint,
      p_previous_account_number: account.accountNumber,
    }));
    const session = await this.auth.requireSession();
    const updated = this.configStore.update({
      linkedOnlineUserId: session.user.id,
      linkedOnlineEmail: session.email,
      walletFingerprint: fingerprint,
      migrationStatus: String(response?.migration_status || ""),
      migrationId: String(response?.migration_id || ""),
    });
    this.status("이 PC가 홈페이지 계정의 연결 기기로 등록되었습니다.", "success");
    return { config: updated, account, server: response };
  }

  async requestMigration() {
    const config = this.requireLocalConfig();
    const account = getAccount(config.databasePath, config.selectedAccountId);
    const fingerprint = fingerprintAccount(account);
    const response = unwrapJson(await this.auth.rpc("request_sd_wallet_migration", {
      p_local_wallet_fingerprint: fingerprint,
      p_previous_account_number: account.accountNumber,
      p_local_username: account.username,
      p_local_owner_name: account.ownerName,
      p_migrated_balance: account.balance,
      p_source_summary: {
        app: "SD Link",
        version: "1.0.0",
        bank_name: account.bankName,
        account_id_hash: fingerprint.slice(0, 16),
        local_transaction_count: listTransactionIds(config.databasePath, account.id).length,
      },
    }));
    const updated = this.configStore.update({
      walletFingerprint: fingerprint,
      migrationId: String(response?.migration_id || ""),
      migrationStatus: String(response?.status || ""),
    });
    this.status(String(response?.message || "잔액 이전 신청을 접수했습니다."), "success");
    return { config: updated, response };
  }

  async snapshot() {
    const config = this.requireLocalConfig();
    const response = unwrapJson(await this.auth.rpc("get_sd_link_snapshot", {
      p_device_key: config.deviceKey,
    }));
    const updated = this.configStore.update({
      migrationStatus: String(response?.migration_status || ""),
      migrationId: String(response?.migration_id || ""),
    });
    return { config: updated, snapshot: response };
  }

  async activate(config, snapshot) {
    const account = getAccount(config.databasePath, config.selectedAccountId);
    const backupPath = backupDatabase(config.databasePath, this.backupDirectory);

    // 최초 이전 승인 전까지의 로컬 거래는 서버에 잔액으로 이미 합산되었으므로 재전송하지 않습니다.
    this.syncState.markManyLocalProcessed(
      listTransactionIds(config.databasePath, account.id),
    );

    const serverBalance = asNumber(snapshot.wallet_balance);
    const adjustment = setAccountBalance(
      config.databasePath,
      account.id,
      serverBalance,
      "SD Link 최초 온라인 계정 연결",
    );
    if (adjustment?.id) this.syncState.markLocalProcessed(adjustment.id);

    const latestSeq = asNumber(snapshot.latest_sync_seq);
    this.syncState.setMeta("server_cursor", latestSeq);
    this.syncState.setMeta("expected_local_balance", serverBalance);
    this.syncState.setMeta("activation_backup", backupPath);
    this.syncState.setMeta("activated_at", new Date().toISOString());

    const updated = this.configStore.update({
      activated: true,
      lastServerCursor: latestSeq,
      lastExpectedLocalBalance: serverBalance,
      migrationStatus: "completed",
    });
    this.status("잔액 이전 승인 완료: PC·홈페이지·모바일 동기화를 시작했습니다.", "success");
    return updated;
  }

  async pushLocalTransactions(config, expectedBalance) {
    const account = getAccount(config.databasePath, config.selectedAccountId);
    let allTransactions = listTransactions(config.databasePath, account.id);
    let pending = allTransactions.filter((transaction) =>
      !this.syncState.isLocalProcessed(transaction.id),
    );

    const pendingNet = pending.reduce((sum, transaction) => sum + signedAmount(transaction), 0);
    const unexplainedDifference = account.balance - (expectedBalance + pendingNet);
    if (unexplainedDifference !== 0) {
      const syntheticId = recordSyntheticTransaction(
        config.databasePath,
        account.id,
        unexplainedDifference,
        "SD Link: 다른 로컬 앱의 잔액 변경 감지",
      );
      if (syntheticId) {
        allTransactions = listTransactions(config.databasePath, account.id);
        pending = allTransactions.filter((transaction) =>
          !this.syncState.isLocalProcessed(transaction.id),
        );
      }
    }

    let pushed = 0;
    let latestServerBalance = expectedBalance;
    for (const transaction of pending) {
      const response = unwrapJson(await this.auth.rpc("push_sd_link_transaction", {
        p_device_key: config.deviceKey,
        p_local_transaction_id: transaction.id,
        p_transaction_type: transaction.transactionType,
        p_description: transaction.memo ||
          (transaction.transactionType === "withdraw" ? "PC 로컬 출금" : "PC 로컬 입금"),
        p_amount: signedAmount(transaction),
        p_local_created_at: transaction.createdAt || new Date().toISOString(),
        p_metadata: { local_account_id: account.id },
      }));
      this.syncState.markLocalProcessed(transaction.id);
      latestServerBalance = asNumber(response?.balance_after, latestServerBalance);
      pushed += 1;
    }
    return { pushed, latestServerBalance };
  }

  async pullRemoteTransactions(config, initialCursor) {
    let cursor = Math.max(0, asNumber(initialCursor));
    let pulled = 0;
    let latestBalance = null;

    while (true) {
      const rows = await this.auth.rpc("pull_sd_link_transactions", {
        p_device_key: config.deviceKey,
        p_after_seq: cursor,
        p_limit: 200,
      });
      const transactions = Array.isArray(rows) ? rows : [];
      if (transactions.length === 0) break;

      for (const remote of transactions) {
        const seq = asNumber(remote.sync_seq, cursor);
        const transactionId = String(remote.transaction_id || remote.id || "");
        const metadata = safeMetadata(remote.metadata);
        const ownTransaction =
          metadata.sd_link_device_key === config.deviceKey &&
          Boolean(metadata.sd_link_local_transaction_id);

        if (!this.syncState.isRemoteApplied(transactionId)) {
          if (ownTransaction) {
            updateBalanceOnly(
              config.databasePath,
              config.selectedAccountId,
              asNumber(remote.balance_after),
            );
          } else {
            const applied = applyRemoteTransaction(
              config.databasePath,
              config.selectedAccountId,
              remote,
            );
            if (applied?.localId) this.syncState.markLocalProcessed(applied.localId);
          }
          this.syncState.markRemoteApplied(transactionId, seq);
          pulled += 1;
        }
        latestBalance = asNumber(remote.balance_after, latestBalance ?? 0);
        cursor = Math.max(cursor, seq);
      }
      if (transactions.length < 200) break;
    }

    this.syncState.setMeta("server_cursor", cursor);
    return { pulled, cursor, latestBalance };
  }

  async syncOnce() {
    if (this.running) {
      return { skipped: true, message: "이미 동기화 중입니다." };
    }
    this.running = true;
    try {
      this.status("온라인 계정과 동기화 중입니다.");
      let { config, snapshot } = await this.snapshot();
      if (snapshot?.migration_status !== "completed") {
        const message = snapshot?.migration_status === "pending"
          ? "기존 잔액 이전이 관리자 승인 대기 중입니다."
          : "먼저 기존 로컬 잔액 이전을 신청하세요.";
        this.configStore.update({ lastSyncAt: new Date().toISOString(), lastSyncMessage: message });
        this.status(message, "warning");
        return { waiting: true, snapshot, message };
      }

      if (!config.activated) {
        config = await this.activate(config, snapshot);
      }

      const expectedBalance = asNumber(
        this.syncState.getMeta(
          "expected_local_balance",
          config.lastExpectedLocalBalance ?? snapshot.wallet_balance,
        ),
      );
      const cursor = asNumber(
        this.syncState.getMeta("server_cursor", config.lastServerCursor || 0),
      );

      const pushResult = await this.pushLocalTransactions(config, expectedBalance);
      const pullResult = await this.pullRemoteTransactions(config, cursor);
      ({ snapshot } = await this.snapshot());

      const serverBalance = asNumber(snapshot.wallet_balance);
      const localAccount = getAccount(config.databasePath, config.selectedAccountId);
      if (localAccount.balance !== serverBalance) {
        const correction = setAccountBalance(
          config.databasePath,
          config.selectedAccountId,
          serverBalance,
          "SD Link 서버 최종 잔액 보정",
        );
        if (correction?.id) this.syncState.markLocalProcessed(correction.id);
      }

      this.syncState.setMeta("expected_local_balance", serverBalance);
      const now = new Date().toISOString();
      const message = `완료 · PC ${pushResult.pushed}건 전송 / 온라인 ${pullResult.pulled}건 반영`;
      const updated = this.configStore.update({
        activated: true,
        lastServerCursor: pullResult.cursor,
        lastExpectedLocalBalance: serverBalance,
        lastSyncAt: now,
        lastSyncMessage: message,
        migrationStatus: String(snapshot.migration_status || "completed"),
      });
      this.status(message, "success");
      return {
        ok: true,
        config: updated,
        snapshot,
        pushed: pushResult.pushed,
        pulled: pullResult.pulled,
      };
    } catch (error) {
      const message = error?.message || "동기화에 실패했습니다.";
      this.configStore.update({
        lastSyncAt: new Date().toISOString(),
        lastSyncMessage: message,
      });
      this.status(message, "error");
      throw error;
    } finally {
      this.running = false;
    }
  }
}

module.exports = { SyncEngine };
