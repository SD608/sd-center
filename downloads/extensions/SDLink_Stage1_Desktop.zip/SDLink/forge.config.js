"use strict";

const path = require("node:path");

module.exports = {
  packagerConfig: {
    asar: true,
    executableName: "SDLink",
    icon: path.join(__dirname, "public", "icons", "icon"),
  },
  rebuildConfig: {},
  makers: [
    {
      name: "@electron-forge/maker-squirrel",
      config: {
        name: "sdlink",
        setupExe: "SDLink-Setup.exe",
        setupIcon: path.join(__dirname, "public", "icons", "icon.ico"),
      },
    },
  ],
};
