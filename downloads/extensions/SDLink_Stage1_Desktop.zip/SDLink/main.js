"use strict";

const fs = require("node:fs");
const path = require("node:path");
const {
  app,
  BrowserWindow,
  dialog,
  ipcMain,
  safeStorage,
  shell,
} = require("electron");
const { ConfigStore } = require("./src/config-store");
const { AuthService } = require("./src/auth-service");
const { inspectDatabase, fingerprintAccount, getAccount } = require("./src/wallet-db");
const { SyncState } = require("./src/sync-state");
const { SyncEngine } = require("./src/sync-engine");

const WEBSITE_URL = "https://sd608.github.io/sd-center/";
const ACCOUNT_URL = `${WEBSITE_URL}account.html`;
const MOBILE_DOWNLOAD_URL =
  "https://github.com/SD608/sd-center/releases/latest/download/SDCenter-Mobile.apk";

let mainWindow = null;
let configStore = null;
let authService = null;
let syncState = null;
let syncEngine = null;
let timer = null;

function sendStatus(payload) {
  if (mainWindow && !mainWindow.isDestroyed()) {
    mainWindow.webContents.send("sdlink:status", payload);
  }
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1080,
    height: 780,
    minWidth: 820,
    minHeight: 640,
    title: "SD Link",
    icon: path.join(__dirname, "public", "icons", "icon-512.png"),
    backgroundColor: "#07111f",
    autoHideMenuBar: true,
    show: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      webSecurity: true,
    },
  });
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: "deny" }));
  mainWindow.webContents.on("will-navigate", (event, url) => {
    if (url !== mainWindow.webContents.getURL()) event.preventDefault();
  });
  mainWindow.once("ready-to-show", () => mainWindow.show());
  mainWindow.on("closed", () => { mainWindow = null; });
  mainWindow.loadFile(path.join(__dirname, "public", "index.html"));
}

function commonCandidates() {
  const roots = [
    process.env.APPDATA,
    process.env.LOCALAPPDATA,
    process.cwd(),
    path.dirname(process.cwd()),
    app.getPath("userData"),
    path.dirname(app.getPath("userData")),
  ].filter(Boolean);
  const suffixes = [
    ["sdwallet-desktop", "data", "sdwallet.sqlite"],
    ["SD지갑", "data", "sdwallet.sqlite"],
    ["SDWallet", "data", "sdwallet.sqlite"],
    ["data", "sdwallet.sqlite"],
    ["sdwallet.sqlite"],
  ];
  const values = new Set();
  for (const root of roots) {
    for (const suffix of suffixes) values.add(path.resolve(root, ...suffix));
  }
  return [...values];
}

function autoDetectWallet() {
  const matches = [];
  for (const candidate of commonCandidates()) {
    if (!fs.existsSync(candidate)) continue;
    try {
      const inspected = inspectDatabase(candidate);
      matches.push(inspected);
    } catch {
      // 다른 SQLite 파일은 무시합니다.
    }
  }
  matches.sort((a, b) => {
    try {
      return fs.statSync(b.path).mtimeMs - fs.statSync(a.path).mtimeMs;
    } catch {
      return 0;
    }
  });
  return matches;
}

function getCurrentLocal() {
  const config = configStore.load();
  if (!config.databasePath || !fs.existsSync(config.databasePath)) return null;
  try {
    const inspection = inspectDatabase(config.databasePath);
    const selected = inspection.accounts.find((item) => item.id === config.selectedAccountId) || null;
    return { ...inspection, selected };
  } catch (error) {
    return { error: error.message, path: config.databasePath };
  }
}

async function appState(includeSnapshot = false) {
  const config = configStore.load();
  const result = {
    config,
    auth: authService.publicSession(),
    local: getCurrentLocal(),
    snapshot: null,
  };
  if (includeSnapshot && result.auth.authenticated && config.databasePath && config.selectedAccountId) {
    try {
      result.snapshot = (await syncEngine.snapshot()).snapshot;
    } catch (error) {
      result.snapshotError = error.message;
    }
  }
  return result;
}

function registerIpc() {
  ipcMain.handle("sdlink:get-state", (_event, includeSnapshot) => appState(Boolean(includeSnapshot)));

  ipcMain.handle("sdlink:auto-detect", () => autoDetectWallet());

  ipcMain.handle("sdlink:choose-db", async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: "SD지갑 데이터베이스 선택",
      properties: ["openFile"],
      filters: [
        { name: "SD지갑 SQLite", extensions: ["sqlite", "db"] },
        { name: "모든 파일", extensions: ["*"] },
      ],
    });
    if (result.canceled || result.filePaths.length === 0) return null;
    return inspectDatabase(result.filePaths[0]);
  });

  ipcMain.handle("sdlink:select-wallet", (_event, databasePath, accountId) => {
    const inspection = inspectDatabase(databasePath);
    const account = inspection.accounts.find((item) => item.id === String(accountId));
    if (!account) throw new Error("선택한 계좌를 찾지 못했습니다.");
    const current = configStore.load();
    const changed =
      path.resolve(databasePath) !== path.resolve(current.databasePath || databasePath) ||
      String(accountId) !== String(current.selectedAccountId || accountId);
    if (changed && current.activated) {
      throw new Error("이미 동기화가 시작된 계좌입니다. 먼저 ‘연결 초기화’를 실행하세요.");
    }
    const fingerprint = fingerprintAccount(account);
    configStore.update({
      databasePath: path.resolve(databasePath),
      selectedAccountId: String(accountId),
      walletFingerprint: fingerprint,
    });
    return appState(false);
  });

  ipcMain.handle("sdlink:login", async (_event, email, password, remember) => {
    const auth = await authService.signIn(String(email).trim(), String(password), Boolean(remember));
    const config = configStore.load();
    if (
      config.linkedOnlineUserId &&
      config.linkedOnlineUserId !== auth.user.id &&
      config.activated
    ) {
      await authService.signOut();
      throw new Error("이 PC는 다른 홈페이지 계정과 이미 연결되어 있습니다. 연결 초기화 후 다시 시도하세요.");
    }
    return appState(false);
  });

  ipcMain.handle("sdlink:logout", async () => {
    await authService.signOut();
    return appState(false);
  });

  ipcMain.handle("sdlink:register-device", async () => syncEngine.registerDevice());
  ipcMain.handle("sdlink:request-migration", async () => syncEngine.requestMigration());
  ipcMain.handle("sdlink:sync", async () => syncEngine.syncOnce());

  ipcMain.handle("sdlink:set-auto-sync", (_event, enabled) => {
    configStore.update({ autoSync: Boolean(enabled) });
    return appState(false);
  });

  ipcMain.handle("sdlink:reset", async () => {
    const answer = await dialog.showMessageBox(mainWindow, {
      type: "warning",
      buttons: ["취소", "연결 초기화"],
      defaultId: 0,
      cancelId: 0,
      title: "SD Link 연결 초기화",
      message: "이 PC의 SD Link 설정과 동기화 기록을 초기화할까요?",
      detail: "로컬 SD지갑 데이터와 홈페이지 계정은 삭제되지 않습니다. 다시 연결하면 서버 잔액으로 재조정됩니다.",
    });
    if (answer.response !== 1) return { canceled: true };
    const current = configStore.load();
    try {
      if (authService.publicSession().authenticated && current.databasePath && current.selectedAccountId) {
        const linked = await syncEngine.snapshot();
        if (linked?.snapshot?.device_id) {
          await authService.rpc("revoke_sd_link_device", {
            p_device_id: linked.snapshot.device_id,
          });
        }
      }
    } catch {
      // 서버 연결이 끊겨 있어도 로컬 초기화는 진행합니다.
    }
    await authService.signOut();
    syncState.clearSynchronizationMarks();
    configStore.save({
      ...current,
      activated: false,
      linkedOnlineUserId: "",
      linkedOnlineEmail: "",
      migrationId: "",
      migrationStatus: "",
      lastServerCursor: 0,
      lastExpectedLocalBalance: null,
      lastSyncAt: "",
      lastSyncMessage: "",
    });
    return appState(false);
  });

  ipcMain.handle("sdlink:open-website", () => shell.openExternal(WEBSITE_URL));
  ipcMain.handle("sdlink:open-account", () => shell.openExternal(ACCOUNT_URL));
  ipcMain.handle("sdlink:open-mobile-download", () => shell.openExternal(MOBILE_DOWNLOAD_URL));
}

function startAutoSync() {
  clearInterval(timer);
  timer = setInterval(async () => {
    const config = configStore.load();
    if (!config.autoSync || !authService.publicSession().authenticated) return;
    if (!config.databasePath || !config.selectedAccountId) return;
    try {
      await syncEngine.syncOnce();
    } catch {
      // 상태 이벤트는 SyncEngine이 전송합니다.
    }
  }, 15_000);
}

app.whenReady().then(() => {
  configStore = new ConfigStore(app.getPath("userData"));
  authService = new AuthService(app.getPath("userData"), safeStorage);
  syncState = new SyncState(app.getPath("userData"));
  syncEngine = new SyncEngine({
    authService,
    configStore,
    syncState,
    userDataDirectory: app.getPath("userData"),
    onStatus: sendStatus,
  });
  registerIpc();
  createWindow();
  startAutoSync();
});

app.on("window-all-closed", () => app.quit());
app.on("before-quit", () => {
  clearInterval(timer);
  try { syncState?.close(); } catch { /* 종료 계속 */ }
});
