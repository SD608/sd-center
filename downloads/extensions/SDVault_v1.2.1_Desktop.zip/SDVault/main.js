"use strict";

const path = require("node:path");
const { isSdCenterUrl, openSdCenter } = require("./src/open-center");
const {
  app,
  BrowserWindow,
  dialog,
  ipcMain,
  session,
} = require("electron");

const { SettingsStore } = require("./src/settings");
const {
  autoFindWalletDatabase,
  readWalletAccounts,
  readWalletAccount,
  validateWalletDatabase,
} = require("./src/wallet-reader");
const {
  fetchGoldPrice,
  normalizeGoldPrice,
} = require("./src/gold-provider");

const hasSingleInstanceLock = app.requestSingleInstanceLock();

if (!hasSingleInstanceLock) {
  app.quit();
}

let mainWindow = null;
let settingsStore = null;

const pinSecurity = {
  failedAttempts: 0,
  lockedUntil: 0,
};

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 980,
    minWidth: 900,
    minHeight: 760,
    title: "SD금고",
    backgroundColor: "#080b12",
    autoHideMenuBar: true,
    icon: path.join(__dirname, "public", "icons", "icon-512.png"),
    show: false,

    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
    },
  });

  mainWindow.webContents.setWindowOpenHandler(() => ({
    action: "deny",
  }));

  mainWindow.webContents.on("will-navigate", (event, navigationUrl) => {
    if (isSdCenterUrl(navigationUrl)) {
      event.preventDefault();
      openSdCenter(app);
      return;
    }

    const allowed = new URL(`file://${path.join(__dirname, "public", "index.html")}`);

    try {
      const target = new URL(navigationUrl);

      if (target.protocol !== "file:" || target.pathname !== allowed.pathname) {
        event.preventDefault();
      }
    } catch {
      event.preventDefault();
    }
  });

  mainWindow.webContents.on("will-attach-webview", (event) => {
    event.preventDefault();
  });

  mainWindow.once("ready-to-show", () => {
    mainWindow.show();
  });

  mainWindow.loadFile(path.join(__dirname, "public", "index.html"));
}

function registerIpcHandlers() {
  ipcMain.handle("settings:get", () => {
    return settingsStore.getPublicSettings();
  });

  ipcMain.handle("settings:save", (event, patch) => {
    return settingsStore.updatePublicSettings(patch);
  });

  ipcMain.handle("wallet:auto-detect", () => {
    const found = autoFindWalletDatabase({
      appDataPath: app.getPath("appData"),
      homePath: app.getPath("home"),
    });

    if (!found) {
      return { found: false };
    }

    settingsStore.update({
      walletDatabasePath: found,
    });

    return {
      found: true,
      path: found,
    };
  });

  ipcMain.handle("wallet:choose-database", async () => {
    const result = await dialog.showOpenDialog(mainWindow, {
      title: "SD지갑 데이터베이스 선택",
      properties: ["openFile"],
      filters: [
        {
          name: "SQLite Database",
          extensions: ["sqlite", "db", "sqlite3"],
        },
      ],
    });

    if (result.canceled || result.filePaths.length === 0) {
      return { canceled: true };
    }

    const databasePath = result.filePaths[0];
    const validation = validateWalletDatabase(databasePath);

    if (!validation.ok) {
      return {
        canceled: false,
        ok: false,
        error: validation.error,
      };
    }

    settingsStore.update({
      walletDatabasePath: databasePath,
      selectedAccountId: "",
    });

    return {
      canceled: false,
      ok: true,
      path: databasePath,
    };
  });

  ipcMain.handle("wallet:list-accounts", () => {
    const settings = settingsStore.get();

    if (!settings.walletDatabasePath) {
      return {
        connected: false,
        accounts: [],
      };
    }

    try {
      const accounts = readWalletAccounts(settings.walletDatabasePath);

      return {
        connected: true,
        databasePath: settings.walletDatabasePath,
        accounts,
      };
    } catch (error) {
      return {
        connected: false,
        databasePath: settings.walletDatabasePath,
        accounts: [],
        error: error.message,
      };
    }
  });

  ipcMain.handle("wallet:get-account", (event, accountId) => {
    const settings = settingsStore.get();

    if (!settings.walletDatabasePath || !accountId) {
      return {
        connected: false,
        account: null,
      };
    }

    try {
      const account = readWalletAccount(
        settings.walletDatabasePath,
        String(accountId),
      );

      return {
        connected: Boolean(account),
        databasePath: settings.walletDatabasePath,
        account,
      };
    } catch (error) {
      return {
        connected: false,
        databasePath: settings.walletDatabasePath,
        account: null,
        error: error.message,
      };
    }
  });

  ipcMain.handle("pin:status", () => {
    const settings = settingsStore.get();

    return {
      configured: settingsStore.hasPin(),
      lockedUntil: pinSecurity.lockedUntil,
    };
  });

  ipcMain.handle("pin:setup", async (event, pin) => {
    const normalizedPin = String(pin || "");

    if (!/^\d{4}$/.test(normalizedPin)) {
      return {
        ok: false,
        error: "PIN은 숫자 4자리여야 합니다.",
      };
    }

    if (settingsStore.hasPin()) {
      return {
        ok: false,
        error: "이미 PIN이 설정되어 있습니다.",
      };
    }

    await settingsStore.setPin(normalizedPin);
    pinSecurity.failedAttempts = 0;
    pinSecurity.lockedUntil = 0;

    return { ok: true };
  });

  ipcMain.handle("pin:verify", async (event, pin) => {
    const now = Date.now();

    if (pinSecurity.lockedUntil > now) {
      return {
        ok: false,
        locked: true,
        lockedUntil: pinSecurity.lockedUntil,
        error: "잠시 후 다시 시도하세요.",
      };
    }

    const valid = await settingsStore.verifyPin(String(pin || ""));

    if (valid) {
      pinSecurity.failedAttempts = 0;
      pinSecurity.lockedUntil = 0;

      return { ok: true };
    }

    pinSecurity.failedAttempts += 1;
    const remaining = Math.max(0, 5 - pinSecurity.failedAttempts);

    if (pinSecurity.failedAttempts >= 5) {
      pinSecurity.failedAttempts = 0;
      pinSecurity.lockedUntil = Date.now() + 30_000;

      return {
        ok: false,
        locked: true,
        lockedUntil: pinSecurity.lockedUntil,
        error: "PIN을 5회 틀려 30초 동안 잠겼습니다.",
      };
    }

    return {
      ok: false,
      locked: false,
      remaining,
      error: `PIN이 올바르지 않습니다. ${remaining}회 남았습니다.`,
    };
  });

  ipcMain.handle("pin:change", async (event, payload) => {
    const currentPin = String(payload?.currentPin || "");
    const newPin = String(payload?.newPin || "");

    if (!/^\d{4}$/.test(newPin)) {
      return {
        ok: false,
        error: "새 PIN은 숫자 4자리여야 합니다.",
      };
    }

    const valid = await settingsStore.verifyPin(currentPin);

    if (!valid) {
      return {
        ok: false,
        error: "현재 PIN이 올바르지 않습니다.",
      };
    }

    await settingsStore.setPin(newPin);

    return { ok: true };
  });

  ipcMain.handle("gold:fetch", async (event, config) => {
    const settings = settingsStore.get();
    const shouldApply = config?.apply !== false;

    const requestConfig = {
      url: String(config?.url || settings.goldApiUrl || "").trim(),
      jsonPath: String(
        config?.jsonPath ?? settings.goldApiJsonPath ?? "",
      ).trim(),
      sourceName: String(
        config?.sourceName || settings.goldSourceName || "사용자 지정 API",
      ).trim(),
      unit: String(config?.unit || settings.goldPriceUnit || "don"),
    };

    if (!requestConfig.url) {
      return {
        ok: true,
        mode: "demo",
        sourceName: "개발용 시세",
        pricePerDonKrw: settings.demoGoldPricePerDon,
        pricePerGramKrw: normalizeGoldPrice(
          settings.demoGoldPricePerDon,
          "don",
        ),
        fetchedAt: new Date().toISOString(),
      };
    }

    try {
      const result = await fetchGoldPrice(requestConfig);

      if (shouldApply) {
        settingsStore.update({
          goldApiUrl: requestConfig.url,
          goldApiJsonPath: requestConfig.jsonPath,
          goldSourceName: requestConfig.sourceName,
          goldPriceUnit: requestConfig.unit,
          lastGoldPricePerGram: result.pricePerGramKrw,
          lastGoldPriceAt: result.fetchedAt,
        });
      }

      return {
        ok: true,
        mode: "api",
        ...result,
      };
    } catch (error) {
      const fallback = settings.lastGoldPricePerGram;

      return {
        ok: false,
        mode: fallback > 0 ? "cached" : "error",
        sourceName: requestConfig.sourceName,
        pricePerGramKrw: fallback || 0,
        fetchedAt: settings.lastGoldPriceAt || "",
        error: error.message,
      };
    }
  });
}

app.whenReady().then(() => {
  settingsStore = new SettingsStore(
    path.join(app.getPath("userData"), "settings.json"),
  );

  registerIpcHandlers();

  session.defaultSession.setPermissionRequestHandler(
    (webContents, permission, callback) => {
      callback(false);
    },
  );

  createWindow();
});

app.on("second-instance", () => {
  if (!mainWindow) {
    return;
  }

  if (mainWindow.isMinimized()) {
    mainWindow.restore();
  }

  mainWindow.show();
  mainWindow.focus();
});

app.on("window-all-closed", () => {
  app.quit();
});
