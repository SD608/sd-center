"use strict";

const bridge = window.sdVault;

const state = {
  settings: null,
  pinConfigured: false,
  pinMode: "verify",
  pinInput: "",
  pinSubmitting: false,
  isVaultOpen: false,
  vaultOpening: false,

  accounts: [],
  account: null,

  goldPrice: {
    mode: "demo",
    pricePerGramKrw: 0,
    pricePerDonKrw: 0,
    sourceName: "개발용 시세",
    fetchedAt: "",
  },

  accountTimer: null,
  toastTimer: null,

  goldRenderSignature: "",
  goldAnimationPlayed: false,
};

const elements = {
  vault: document.getElementById("vault"),
  vaultDial: document.getElementById("vaultDial"),
  vaultStatus: document.getElementById("vaultStatus"),
  goldShelves: document.getElementById("goldShelves"),
  vaultTotalWeight: document.getElementById("vaultTotalWeight"),
  closeVaultButton: document.getElementById("closeVaultButton"),

  settingsButton: document.getElementById("settingsButton"),
  settingsModal: document.getElementById("settingsModal"),
  closeSettingsButton: document.getElementById("closeSettingsButton"),

  pinModal: document.getElementById("pinModal"),
  pinModalTitle: document.getElementById("pinModalTitle"),
  pinModalDescription: document.getElementById("pinModalDescription"),
  closePinModalButton: document.getElementById("closePinModalButton"),
  pinDots: [...document.querySelectorAll("#pinDots span")],
  pinKeypad: document.getElementById("pinKeypad"),
  pinMessage: document.getElementById("pinMessage"),

  walletDisconnected: document.getElementById("walletDisconnected"),
  walletConnected: document.getElementById("walletConnected"),
  connectWalletButton: document.getElementById("connectWalletButton"),
  changeWalletButton: document.getElementById("changeWalletButton"),

  accountBank: document.getElementById("accountBank"),
  accountNumber: document.getElementById("accountNumber"),
  accountOwner: document.getElementById("accountOwner"),
  accountBalance: document.getElementById("accountBalance"),
  accountUpdatedAt: document.getElementById("accountUpdatedAt"),

  goldPricePerGram: document.getElementById("goldPricePerGram"),
  goldPricePerDon: document.getElementById("goldPricePerDon"),
  goldSource: document.getElementById("goldSource"),
  goldFetchedAt: document.getElementById("goldFetchedAt"),
  priceModeBadge: document.getElementById("priceModeBadge"),
  refreshGoldButton: document.getElementById("refreshGoldButton"),

  goldEquivalent: document.getElementById("goldEquivalent"),
  goldBarSummary: document.getElementById("goldBarSummary"),

  autoDetectWalletButton: document.getElementById("autoDetectWalletButton"),
  chooseWalletDatabaseButton: document.getElementById(
    "chooseWalletDatabaseButton",
  ),
  walletPathText: document.getElementById("walletPathText"),
  accountSelect: document.getElementById("accountSelect"),

  goldApiUrl: document.getElementById("goldApiUrl"),
  goldPriceUnit: document.getElementById("goldPriceUnit"),
  goldSourceName: document.getElementById("goldSourceName"),
  goldApiJsonPath: document.getElementById("goldApiJsonPath"),
  testGoldApiButton: document.getElementById("testGoldApiButton"),
  saveSettingsButton: document.getElementById("saveSettingsButton"),
  goldApiTestMessage: document.getElementById("goldApiTestMessage"),

  currentPinInput: document.getElementById("currentPinInput"),
  newPinInput: document.getElementById("newPinInput"),
  changePinButton: document.getElementById("changePinButton"),
  changePinMessage: document.getElementById("changePinMessage"),

  toast: document.getElementById("toast"),
};

function formatMoney(value) {
  return new Intl.NumberFormat("ko-KR", {
    style: "currency",
    currency: "KRW",
    maximumFractionDigits: 0,
  }).format(Number(value || 0));
}

function formatDate(value) {
  if (!value) {
    return "-";
  }

  const date = new Date(value);

  if (Number.isNaN(date.getTime())) {
    return "-";
  }

  return new Intl.DateTimeFormat("ko-KR", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).format(date);
}

function resetGoldPriceToWaiting() {
  state.goldPrice = {
    mode: "waiting",
    pricePerGramKrw: 0,
    pricePerDonKrw: 0,
    sourceName: "새로고침 대기",
    fetchedAt: "",
  };
}

function maskAccountNumber(value) {
  const text = String(value || "");

  if (text.length <= 6) {
    return text;
  }

  return `${text.slice(0, 4)}••••${text.slice(-4)}`;
}

function showToast(message) {
  window.clearTimeout(state.toastTimer);
  elements.toast.textContent = message;
  elements.toast.classList.add("show");

  state.toastTimer = window.setTimeout(() => {
    elements.toast.classList.remove("show");
  }, 2600);
}

function openSettings() {
  populateSettingsForm();
  elements.settingsModal.classList.remove("hidden");
}

function closeSettings() {
  elements.settingsModal.classList.add("hidden");
}

function openPinModal(mode) {
  state.pinMode = mode;
  state.pinInput = "";
  updatePinDots();
  elements.pinMessage.textContent = "";

  if (mode === "setup") {
    elements.pinModalTitle.textContent = "첫 PIN 설정";
    elements.pinModalDescription.textContent =
      "금고를 열 때 사용할 숫자 4자리를 설정하세요.";
  } else {
    elements.pinModalTitle.textContent = "금고 PIN 입력";
    elements.pinModalDescription.textContent =
      "금고를 열려면 숫자 4자리 PIN을 입력하세요.";
  }

  elements.pinModal.classList.remove("hidden");
}

function closePinModal() {
  elements.pinModal.classList.add("hidden");
  state.pinInput = "";
  updatePinDots();
}

function updatePinDots() {
  elements.pinDots.forEach((dot, index) => {
    dot.classList.toggle("filled", index < state.pinInput.length);
  });
}

async function submitPin() {
  if (state.pinInput.length !== 4 || state.pinSubmitting) {
    return;
  }

  state.pinSubmitting = true;
  const pin = state.pinInput;
  state.pinInput = "";

  try {
    if (state.pinMode === "setup") {
      const result = await bridge.setupPin(pin);

      if (!result.ok) {
        elements.pinMessage.textContent = result.error;
        updatePinDots();
        return;
      }

      state.pinConfigured = true;
      closePinModal();
      showToast("4자리 PIN이 설정되었습니다.");
      await runVaultOpeningSequence();
      return;
    }

    const result = await bridge.verifyPin(pin);

    if (!result.ok) {
      elements.pinMessage.textContent = result.error;
      updatePinDots();
      elements.vault.classList.remove("pin-error");
      void elements.vault.offsetWidth;
      elements.vault.classList.add("pin-error");
      return;
    }

    closePinModal();
    await runVaultOpeningSequence();
  } finally {
    state.pinSubmitting = false;
  }
}

async function requestOpenVault() {
  if (state.isVaultOpen || state.vaultOpening) {
    return;
  }

  const status = await bridge.getPinStatus();
  state.pinConfigured = status.configured;

  if (status.lockedUntil > Date.now()) {
    const seconds = Math.ceil(
      (status.lockedUntil - Date.now()) / 1000,
    );
    showToast(`금고가 잠겨 있습니다. ${seconds}초 후 시도하세요.`);
    return;
  }

  openPinModal(state.pinConfigured ? "verify" : "setup");
}

async function runVaultOpeningSequence() {
  if (state.vaultOpening || state.isVaultOpen) {
    return;
  }

  state.vaultOpening = true;
  elements.closeVaultButton.classList.add("hidden");
  elements.vault.classList.remove("is-open", "is-unlocking");
  elements.vault.classList.add("is-locked");
  elements.vaultStatus.textContent = "최신 금 시세 확인 중...";

  try {
    // 금고를 열 때마다 계좌 잔액과 금 시세를 새로 확인합니다.
    await loadSelectedAccount();

    const priceResult = await fetchGoldPrice(false, {
      render: false,
    });

    if (
      priceResult &&
      !priceResult.ok &&
      priceResult.mode === "cached"
    ) {
      showToast(
        "실시간 시세 연결에 실패해 마지막 정상 시세를 적용했습니다.",
      );
    } else if (
      !priceResult ||
      !Number(priceResult.pricePerGramKrw || 0)
    ) {
      showToast(
        "금 시세를 불러오지 못했습니다. API 설정을 확인하세요.",
      );
    }

    // 금괴 DOM은 미리 만들지만 애니메이션 전까지 완전히 숨깁니다.
    state.isVaultOpen = true;
    renderGold({
      force: true,
      animate: true,
    });

    // 1. 다이얼과 손잡이 잠금 해제 모션
    elements.vaultStatus.textContent = "잠금장치 해제 중...";
    elements.vault.classList.add("is-unlocking");
    await wait(1050);

    // 2. 금고 문을 완전히 엽니다.
    elements.vaultStatus.textContent = "금고 문 여는 중...";
    elements.vault.classList.remove("is-locked");
    elements.vault.classList.add("is-open");
    await wait(1400);

    // 3. 문이 완전히 열린 뒤 금괴가 아래층부터 생성됩니다.
    elements.vaultStatus.textContent = "금괴 한 개씩 생성 중...";
    const goldAnimationDuration =
      startGoldCreationAnimation();
    await wait(goldAnimationDuration);

    // 4. 생성 완료 후 고정
    elements.vaultStatus.textContent =
      "금고가 열렸습니다 · 금고를 클릭하면 닫힙니다";
    elements.closeVaultButton.classList.remove("hidden");
  } finally {
    state.vaultOpening = false;
  }
}

function toggleVault() {
  if (state.vaultOpening) {
    return;
  }

  if (state.isVaultOpen) {
    closeVault();
    return;
  }

  requestOpenVault();
}

function closeVault() {
  elements.vault.classList.remove("is-open");
  elements.vault.classList.add("is-locked");
  elements.vaultStatus.textContent = "금고를 클릭해 여세요";
  elements.closeVaultButton.classList.add("hidden");
  state.isVaultOpen = false;
  state.vaultOpening = false;

  window.setTimeout(() => {
    elements.vault.classList.remove("is-unlocking");
  }, 1000);
}

function wait(milliseconds) {
  return new Promise((resolve) =>
    window.setTimeout(resolve, milliseconds),
  );
}

async function loadWalletAccounts() {
  const result = await bridge.listWalletAccounts();

  state.accounts = result.accounts || [];
  elements.accountSelect.replaceChildren();

  if (!result.connected) {
    elements.walletPathText.textContent =
      result.error || "연결된 SD지갑 DB 없음";

    const option = document.createElement("option");
    option.value = "";
    option.textContent = "계좌를 먼저 불러오세요";
    elements.accountSelect.appendChild(option);

    state.account = null;
    renderAccount();
    return;
  }

  elements.walletPathText.textContent = result.databasePath;

  if (state.accounts.length === 0) {
    const option = document.createElement("option");
    option.value = "";
    option.textContent = "SD지갑에 계좌가 없습니다";
    elements.accountSelect.appendChild(option);
    state.account = null;
    renderAccount();
    return;
  }

  for (const account of state.accounts) {
    const option = document.createElement("option");
    option.value = account.id;
    option.textContent =
      `${account.bankName} · ${account.accountNumber} · ${formatMoney(account.balance)}`;
    elements.accountSelect.appendChild(option);
  }

  const selectedExists = state.accounts.some(
    (account) =>
      account.id === state.settings.selectedAccountId,
  );

  const selectedId = selectedExists
    ? state.settings.selectedAccountId
    : state.accounts[0].id;

  elements.accountSelect.value = selectedId;

  state.settings = await bridge.saveSettings({
    selectedAccountId: selectedId,
  });

  await loadSelectedAccount();
}

async function loadSelectedAccount() {
  const accountId =
    state.settings.selectedAccountId ||
    elements.accountSelect.value;

  if (!accountId) {
    state.account = null;
    renderAccount();
    return;
  }

  const result = await bridge.getWalletAccount(accountId);

  if (!result.connected || !result.account) {
    state.account = null;
    renderAccount();
    return;
  }

  state.account = result.account;
  renderAccount();
  renderGold();
}

function renderAccount() {
  const connected = Boolean(state.account);

  elements.walletDisconnected.classList.toggle(
    "hidden",
    connected,
  );
  elements.walletConnected.classList.toggle(
    "hidden",
    !connected,
  );

  if (!connected) {
    elements.accountBank.textContent = "-";
    elements.accountNumber.textContent = "-";
    elements.accountOwner.textContent = "-";
    elements.accountBalance.textContent = formatMoney(0);
    elements.accountUpdatedAt.textContent = "-";
    return;
  }

  elements.accountBank.textContent = state.account.bankName;
  elements.accountNumber.textContent = maskAccountNumber(
    state.account.accountNumber,
  );
  elements.accountOwner.textContent = state.account.ownerName;
  elements.accountBalance.textContent = formatMoney(
    state.account.balance,
  );
  elements.accountUpdatedAt.textContent =
    `SD지갑 갱신: ${formatDate(state.account.updatedAt)}`;
}

async function fetchGoldPrice(
  showResult = false,
  options = {},
) {
  const shouldRender = options.render !== false;
  elements.refreshGoldButton.disabled = true;

  try {
    const result = await bridge.fetchGoldPrice({
      url: state.settings.goldApiUrl,
      jsonPath: state.settings.goldApiJsonPath,
      sourceName: state.settings.goldSourceName,
      unit: state.settings.goldPriceUnit,
      apply: true,
    });

    state.goldPrice = result;

    if (result.ok && result.mode === "api") {
      state.settings = await bridge.getSettings();
    }

    renderGoldPrice();

    if (shouldRender) {
      renderGold();
    }

    if (showResult) {
      showToast(
        result.ok
          ? "금 시세를 불러왔습니다."
          : result.error,
      );
    }

    return result;
  } catch (error) {
    if (showResult) {
      showToast(error.message);
    }

    return {
      ok: false,
      mode: "error",
      pricePerGramKrw: 0,
      pricePerDonKrw: 0,
      sourceName: state.settings.goldSourceName || "금 시세 API",
      fetchedAt: "",
      error: error.message,
    };
  } finally {
    elements.refreshGoldButton.disabled = false;
  }
}

function renderGoldPrice() {
  const pricePerGram = Number(
    state.goldPrice.pricePerGramKrw || 0,
  );
  const pricePerDon = Number(
    state.goldPrice.pricePerDonKrw ||
      pricePerGram * 3.75,
  );

  elements.goldPricePerGram.textContent =
    formatMoney(Math.round(pricePerGram));
  elements.goldPricePerDon.textContent =
    formatMoney(Math.round(pricePerDon));
  elements.goldSource.textContent =
    state.goldPrice.sourceName || "-";
  elements.goldFetchedAt.textContent =
    formatDate(state.goldPrice.fetchedAt);

  const mode = state.goldPrice.mode || "error";
  elements.priceModeBadge.className =
    `status-badge ${mode}`;

  elements.priceModeBadge.textContent =
    mode === "api"
      ? "LIVE API"
      : mode === "cached"
        ? "CACHED"
        : mode === "demo"
          ? "DEMO"
          : mode === "waiting"
            ? "REFRESH"
            : "ERROR";
}

function formatGoldWeight(grams) {
  const numericGrams = Math.max(
    0,
    Number(grams || 0),
  );

  if (numericGrams >= 1000) {
    const kilograms = numericGrams / 1000;

    return `${kilograms.toLocaleString("ko-KR", {
      minimumFractionDigits: 0,
      maximumFractionDigits: 3,
    })}kg`;
  }

  return `${numericGrams.toLocaleString("ko-KR", {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  })}g`;
}

const GOLD_BAR_GRAMS = 3.75;
const STANDARD_VAULT_MAX_BARS = 200;
const LARGE_VAULT_MAX_BARS = 500;
const MAX_RENDERED_GOLD_BARS = 2500;

function calculateGoldBarDetails(totalGrams) {
  if (!Number.isFinite(totalGrams) || totalGrams <= 0) {
    return {
      fullBarCount: 0,
      renderedBarCount: 0,
      remainderGrams: 0,
    };
  }

  const fullBarCount = Math.floor(
    (totalGrams + 1e-9) / GOLD_BAR_GRAMS,
  );
  const remainderGrams = Math.max(
    0,
    totalGrams - fullBarCount * GOLD_BAR_GRAMS,
  );

  return {
    fullBarCount,
    renderedBarCount: Math.min(
      fullBarCount,
      MAX_RENDERED_GOLD_BARS,
    ),
    remainderGrams,
  };
}

function getVaultLayout(fullBarCount) {
  const count = Number(fullBarCount || 0);

  if (count > LARGE_VAULT_MAX_BARS) {
    return {
      mode: "ultra",
      label: "초대형 금고",
      barsPerRow: 50,
      fixedBarSize: true,
    };
  }

  if (count > STANDARD_VAULT_MAX_BARS) {
    return {
      mode: "large",
      label: "대형 금고",
      barsPerRow: 20,
      fixedBarSize: false,
    };
  }

  return {
    mode: "standard",
    label: "일반 금고",
    barsPerRow: 10,
    fixedBarSize: false,
  };
}


function renderGold(options = {}) {
  const balance = Number(state.account?.balance || 0);
  const pricePerGram = Number(
    state.goldPrice.pricePerGramKrw || 0,
  );

  const grams =
    balance > 0 && pricePerGram > 0
      ? balance / pricePerGram
      : 0;

  const formattedWeight = formatGoldWeight(grams);

  const barDetails = calculateGoldBarDetails(grams);
  const vaultLayout = getVaultLayout(
    barDetails.fullBarCount,
  );

  elements.goldEquivalent.textContent = formattedWeight;
  elements.vaultTotalWeight.textContent = formattedWeight;
  elements.goldBarSummary.textContent =
    `${vaultLayout.label} · 한 줄 ${vaultLayout.barsPerRow}개 보관 · 금괴 ${barDetails.fullBarCount.toLocaleString(
      "ko-KR",
    )}개 · 잔여 ${barDetails.remainderGrams.toLocaleString(
      "ko-KR",
      {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2,
      },
    )}g`;
  renderGoldShelves(grams, options);
}

function renderGoldShelves(totalGrams, options = {}) {
  const force = options.force === true;
  const animate = options.animate === true;
  const accountId = state.account?.id || "none";
  const balance = Number(state.account?.balance || 0);
  const pricePerGram = Number(
    state.goldPrice.pricePerGramKrw || 0,
  );
  const barDetails = calculateGoldBarDetails(totalGrams);
  const vaultLayout = getVaultLayout(
    barDetails.fullBarCount,
  );

  let renderMode = "gold";

  if (!state.account) {
    renderMode = "no-account";
  } else if (!pricePerGram || totalGrams <= 0) {
    renderMode = "no-price";
  } else if (barDetails.fullBarCount === 0) {
    renderMode = "fraction-only";
  }

  elements.vault.classList.toggle(
    "is-large-capacity",
    renderMode === "gold" &&
      vaultLayout.mode === "large",
  );
  elements.vault.classList.toggle(
    "is-ultra-capacity",
    renderMode === "gold" &&
      vaultLayout.mode === "ultra",
  );

  const signature = [
    renderMode,
    accountId,
    balance,
    pricePerGram,
    vaultLayout.mode,
    vaultLayout.barsPerRow,
    barDetails.fullBarCount,
    barDetails.renderedBarCount,
  ].join("|");

  if (
    !force &&
    state.goldRenderSignature === signature &&
    elements.goldShelves.childElementCount > 0
  ) {
    return;
  }

  state.goldRenderSignature = signature;
  elements.goldShelves.replaceChildren();

  if (renderMode === "no-account") {
    const empty = document.createElement("div");
    empty.className = "empty-vault";
    empty.textContent = "SD지갑 계좌를 연결하세요.";
    elements.goldShelves.appendChild(empty);
    return;
  }

  if (renderMode === "no-price") {
    const empty = document.createElement("div");
    empty.className = "empty-vault";
    empty.textContent =
      "금 시세 새로고침 버튼을 눌러 시세를 적용하세요.";
    elements.goldShelves.appendChild(empty);
    return;
  }

  if (renderMode === "fraction-only") {
    const empty = document.createElement("div");
    empty.className = "empty-vault";
    empty.textContent =
      "현재 금 중량이 3.75g 미만이라 완성된 금괴가 없습니다.";
    elements.goldShelves.appendChild(empty);
    return;
  }

  const stack = document.createElement("div");
  stack.className = animate
    ? `gold-stack gold-stack-${vaultLayout.mode} is-prepared`
    : `gold-stack gold-stack-${vaultLayout.mode}`;
  stack.setAttribute("aria-hidden", "true");
  stack.dataset.barCount = String(
    barDetails.renderedBarCount,
  );

  const barsPerRow = vaultLayout.barsPerRow;
  const rowCount = Math.ceil(
    barDetails.renderedBarCount / barsPerRow,
  );
  const dynamicBarHeight =
    vaultLayout.mode === "ultra"
      ? 18
      : vaultLayout.mode === "large"
        ? Math.max(10, Math.min(18, Math.floor(450 / Math.max(1, rowCount))))
        : Math.max(4, Math.min(18, Math.floor(450 / Math.max(1, rowCount))));
  const overlap = Math.min(
    3,
    Math.max(0, Math.floor(dynamicBarHeight * 0.16)),
  );
  const barWidth =
    vaultLayout.mode === "ultra"
      ? 43
      : vaultLayout.mode === "large"
        ? 26
        : 43;
  const barGap =
    vaultLayout.mode === "large" ? 2 : 3;

  stack.style.setProperty(
    "--gold-bar-height",
    `${dynamicBarHeight}px`,
  );
  stack.style.setProperty(
    "--gold-row-overlap",
    `${overlap}px`,
  );
  stack.style.setProperty(
    "--gold-bars-per-row",
    String(barsPerRow),
  );
  stack.style.setProperty(
    "--gold-bar-width",
    `${barWidth}px`,
  );
  stack.style.setProperty(
    "--gold-bar-gap",
    `${barGap}px`,
  );

  const animationInterval = Math.max(
    5,
    Math.min(
      90,
      Math.floor(
        5000 /
          Math.max(1, barDetails.renderedBarCount),
      ),
    ),
  );

  let globalBarIndex = 0;

  for (let rowIndex = 0; rowIndex < rowCount; rowIndex += 1) {
    const row = document.createElement("div");
    row.className = "gold-row";

    const remaining =
      barDetails.renderedBarCount -
      rowIndex * barsPerRow;
    const barsInRow = Math.min(
      barsPerRow,
      remaining,
    );

    for (
      let columnIndex = 0;
      columnIndex < barsInRow;
      columnIndex += 1
    ) {
      const bar = document.createElement("div");
      bar.className = "gold-bar";
      bar.style.setProperty(
        "--bar-delay",
        `${globalBarIndex * animationInterval}ms`,
      );
      row.appendChild(bar);
      globalBarIndex += 1;
    }

    stack.appendChild(row);
  }

  const animationDuration =
    Math.max(
      0,
      (barDetails.renderedBarCount - 1) *
        animationInterval,
    ) + 430;

  stack.dataset.animationDuration = String(
    animationDuration,
  );

  elements.goldShelves.appendChild(stack);

  const note = document.createElement("div");
  note.className = "gold-overflow-note";

  if (vaultLayout.mode === "ultra") {
    note.textContent =
      `초대형 금고 자동 전환 · 한 줄 ${barsPerRow}개 · 금괴 크기 고정 · 내부 스크롤`;
  } else if (vaultLayout.mode === "large") {
    note.textContent =
      `대형 금고 자동 전환 · 한 줄 ${barsPerRow}개 보관`;
  } else {
    note.textContent =
      `일반 금고 · 한 줄 ${barsPerRow}개 보관`;
  }

  if (
    barDetails.fullBarCount >
    barDetails.renderedBarCount
  ) {
    note.textContent += ` · 화면 표시 ${barDetails.renderedBarCount.toLocaleString(
      "ko-KR",
    )}개 / 전체 ${barDetails.fullBarCount.toLocaleString(
      "ko-KR",
    )}개`;
  }

  elements.goldShelves.appendChild(note);
}

function startGoldCreationAnimation() {
  const stack = elements.goldShelves.querySelector(
    ".gold-stack.is-prepared",
  );

  if (!stack) {
    return 250;
  }

  const duration = Math.max(
    250,
    Number(stack.dataset.animationDuration || 0),
  );

  void stack.offsetWidth;
  stack.classList.add("is-creating");

  window.setTimeout(() => {
    stack.classList.remove("is-prepared", "is-creating");
  }, duration);

  return duration;
}

function populateSettingsForm() {
  elements.goldApiUrl.value =
    state.settings.goldApiUrl || "";
  elements.goldPriceUnit.value =
    state.settings.goldPriceUnit || "don";
  elements.goldSourceName.value =
    state.settings.goldSourceName || "";
  elements.goldApiJsonPath.value =
    state.settings.goldApiJsonPath || "";

  elements.walletPathText.textContent =
    state.settings.walletDatabasePath ||
    "연결된 DB 없음";

  if (state.settings.selectedAccountId) {
    elements.accountSelect.value =
      state.settings.selectedAccountId;
  }
}

async function autoDetectWallet() {
  elements.autoDetectWalletButton.disabled = true;

  try {
    const result = await bridge.autoDetectWallet();

    if (!result.found) {
      showToast(
        "SD지갑 DB를 자동으로 찾지 못했습니다. 직접 선택하세요.",
      );
      return;
    }

    state.settings = await bridge.getSettings();
    await loadWalletAccounts();
    showToast("SD지갑 데이터베이스를 찾았습니다.");
  } finally {
    elements.autoDetectWalletButton.disabled = false;
  }
}

async function chooseWalletDatabase() {
  const result = await bridge.chooseWalletDatabase();

  if (result.canceled) {
    return;
  }

  if (!result.ok) {
    showToast(result.error);
    return;
  }

  state.settings = await bridge.getSettings();
  await loadWalletAccounts();
  showToast("SD지갑 DB가 연결되었습니다.");
}

function currentApiFormConfig() {
  return {
    url: elements.goldApiUrl.value.trim(),
    jsonPath: elements.goldApiJsonPath.value.trim(),
    sourceName:
      elements.goldSourceName.value.trim() ||
      "사용자 지정 API",
    unit: elements.goldPriceUnit.value,
    apply: false,
  };
}

async function testGoldApi() {
  elements.goldApiTestMessage.textContent = "API 확인 중...";
  elements.testGoldApiButton.disabled = true;

  try {
    const result = await bridge.fetchGoldPrice(
      currentApiFormConfig(),
    );

    if (!result.ok && result.mode === "error") {
      elements.goldApiTestMessage.textContent = result.error;
      return;
    }

    elements.goldApiTestMessage.textContent =
      `${result.sourceName}: 1g당 ${formatMoney(
        Math.round(result.pricePerGramKrw),
      )} 확인`;
  } catch (error) {
    elements.goldApiTestMessage.textContent = error.message;
  } finally {
    elements.testGoldApiButton.disabled = false;
  }
}

async function saveSettings() {
  const selectedAccountId = elements.accountSelect.value;
  const nextApiUrl = elements.goldApiUrl.value.trim();
  const nextJsonPath = elements.goldApiJsonPath.value.trim();
  const nextUnit = elements.goldPriceUnit.value;

  const apiDefinitionChanged =
    nextApiUrl !== (state.settings.goldApiUrl || "") ||
    nextJsonPath !== (state.settings.goldApiJsonPath || "") ||
    nextUnit !== (state.settings.goldPriceUnit || "don");

  state.settings = await bridge.saveSettings({
    selectedAccountId,
    goldApiUrl: nextApiUrl,
    goldApiJsonPath: nextJsonPath,
    goldSourceName: elements.goldSourceName.value,
    goldPriceUnit: nextUnit,
    lastGoldPricePerGram: apiDefinitionChanged
      ? 0
      : state.settings.lastGoldPricePerGram,
    lastGoldPriceAt: apiDefinitionChanged
      ? ""
      : state.settings.lastGoldPriceAt,
  });

  await loadSelectedAccount();
  resetGoldPriceToWaiting();
  renderGoldPrice();
  renderGold();
  restartAccountTimer();

  closeSettings();
  showToast("설정이 저장되었습니다. 시세는 새로고침 버튼으로 적용하세요.");
}

async function changePin() {
  const currentPin = elements.currentPinInput.value;
  const newPin = elements.newPinInput.value;

  const result = await bridge.changePin(
    currentPin,
    newPin,
  );

  elements.changePinMessage.textContent = result.ok
    ? "PIN이 변경되었습니다."
    : result.error;

  if (result.ok) {
    elements.currentPinInput.value = "";
    elements.newPinInput.value = "";
  }
}

function restartAccountTimer() {
  window.clearInterval(state.accountTimer);

  state.accountTimer = window.setInterval(
    loadSelectedAccount,
    2000,
  );
}

function bindEvents() {
  elements.vault.addEventListener("click", toggleVault);

  elements.vault.addEventListener("keydown", (event) => {
    if (event.key === "Enter" || event.key === " ") {
      event.preventDefault();
      toggleVault();
    }
  });

  elements.closeVaultButton.addEventListener(
    "click",
    closeVault,
  );

  elements.settingsButton.addEventListener(
    "click",
    openSettings,
  );

  elements.closeSettingsButton.addEventListener(
    "click",
    closeSettings,
  );

  elements.settingsModal.addEventListener("click", (event) => {
    if (event.target === elements.settingsModal) {
      closeSettings();
    }
  });

  elements.closePinModalButton.addEventListener(
    "click",
    closePinModal,
  );

  elements.pinModal.addEventListener("click", (event) => {
    if (event.target === elements.pinModal) {
      closePinModal();
    }
  });

  elements.pinKeypad.addEventListener("click", async (event) => {
    const button = event.target.closest("button");

    if (!button) {
      return;
    }

    if (button.dataset.pin) {
      if (state.pinInput.length < 4) {
        state.pinInput += button.dataset.pin;
        updatePinDots();

        if (state.pinInput.length === 4) {
          await wait(120);
          await submitPin();
        }
      }

      return;
    }

    if (button.dataset.action === "clear") {
      state.pinInput = "";
    }

    if (button.dataset.action === "delete") {
      state.pinInput = state.pinInput.slice(0, -1);
    }

    updatePinDots();
  });

  elements.connectWalletButton.addEventListener(
    "click",
    openSettings,
  );

  elements.changeWalletButton.addEventListener(
    "click",
    openSettings,
  );

  elements.autoDetectWalletButton.addEventListener(
    "click",
    autoDetectWallet,
  );

  elements.chooseWalletDatabaseButton.addEventListener(
    "click",
    chooseWalletDatabase,
  );

  elements.accountSelect.addEventListener(
    "change",
    async () => {
      state.settings = await bridge.saveSettings({
        selectedAccountId: elements.accountSelect.value,
      });

      await loadSelectedAccount();
    },
  );

  elements.testGoldApiButton.addEventListener(
    "click",
    testGoldApi,
  );

  elements.saveSettingsButton.addEventListener(
    "click",
    saveSettings,
  );

  elements.changePinButton.addEventListener(
    "click",
    changePin,
  );

  elements.refreshGoldButton.addEventListener(
    "click",
    () => fetchGoldPrice(true),
  );


  document.addEventListener("keydown", async (event) => {
    const pinModalOpen =
      !elements.pinModal.classList.contains("hidden");

    if (pinModalOpen) {
      if (/^\d$/.test(event.key)) {
        event.preventDefault();

        if (state.pinInput.length < 4 && !state.pinSubmitting) {
          state.pinInput += event.key;
          updatePinDots();

          if (state.pinInput.length === 4) {
            await wait(120);
            await submitPin();
          }
        }
        return;
      }

      if (event.key === "Backspace") {
        event.preventDefault();
        state.pinInput = state.pinInput.slice(0, -1);
        updatePinDots();
        return;
      }

      if (event.key === "Delete" || event.key.toLowerCase() === "c") {
        event.preventDefault();
        state.pinInput = "";
        updatePinDots();
        return;
      }

      if (event.key === "Enter") {
        event.preventDefault();
        await submitPin();
        return;
      }

      if (event.key === "Escape") {
        event.preventDefault();
        closePinModal();
        return;
      }
    }

    if (event.key === "Escape") {
      closeSettings();
    }
  });
}

async function initialize() {
  bindEvents();

  state.settings = await bridge.getSettings();

  const pinStatus = await bridge.getPinStatus();
  state.pinConfigured = pinStatus.configured;

  await loadWalletAccounts();

  if (
    !state.settings.walletDatabasePath ||
    state.accounts.length === 0
  ) {
    const detected = await bridge.autoDetectWallet();

    if (detected.found) {
      state.settings = await bridge.getSettings();
      await loadWalletAccounts();
    }
  }

  resetGoldPriceToWaiting();
  restartAccountTimer();

  renderAccount();
  renderGoldPrice();
  renderGold();
}

initialize().catch((error) => {
  console.error(error);
  showToast(`초기화 오류: ${error.message}`);
});
