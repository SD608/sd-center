"use strict";

const fs = require("node:fs");
const path = require("node:path");
const { DatabaseSync } = require("node:sqlite");

function openDatabase(databasePath) {
  if (!databasePath || !fs.existsSync(databasePath)) {
    throw new Error("SD지갑 데이터베이스 파일을 찾을 수 없습니다.");
  }

  return new DatabaseSync(databasePath, {
    readOnly: true,
  });
}

function validateWalletDatabase(databasePath) {
  let db;

  try {
    db = openDatabase(databasePath);

    const tables = db
      .prepare(
        `
          SELECT name
          FROM sqlite_master
          WHERE type = 'table'
            AND name IN ('users', 'accounts')
        `,
      )
      .all()
      .map((row) => row.name);

    if (!tables.includes("users") || !tables.includes("accounts")) {
      return {
        ok: false,
        error:
          "선택한 파일은 SD지갑 데이터베이스 형식이 아닙니다.",
      };
    }

    return { ok: true };
  } catch (error) {
    return {
      ok: false,
      error: error.message,
    };
  } finally {
    if (db) {
      db.close();
    }
  }
}

function readWalletAccounts(databasePath) {
  const db = openDatabase(databasePath);

  try {
    const rows = db
      .prepare(
        `
          SELECT
            accounts.id,
            accounts.bank_name,
            accounts.account_number,
            accounts.owner_name,
            accounts.balance,
            accounts.updated_at,
            users.username
          FROM accounts
          LEFT JOIN users ON users.id = accounts.user_id
          ORDER BY accounts.updated_at DESC
        `,
      )
      .all();

    return rows.map((row) => ({
      id: String(row.id),
      bankName: String(row.bank_name),
      accountNumber: String(row.account_number),
      ownerName: String(row.owner_name),
      balance: Number(row.balance),
      updatedAt: String(row.updated_at),
      username: String(row.username || "로컬 사용자"),
    }));
  } finally {
    db.close();
  }
}

function readWalletAccount(databasePath, accountId) {
  const db = openDatabase(databasePath);

  try {
    const row = db
      .prepare(
        `
          SELECT
            accounts.id,
            accounts.bank_name,
            accounts.account_number,
            accounts.owner_name,
            accounts.balance,
            accounts.updated_at,
            users.username
          FROM accounts
          LEFT JOIN users ON users.id = accounts.user_id
          WHERE accounts.id = ?
        `,
      )
      .get(accountId);

    if (!row) {
      return null;
    }

    return {
      id: String(row.id),
      bankName: String(row.bank_name),
      accountNumber: String(row.account_number),
      ownerName: String(row.owner_name),
      balance: Number(row.balance),
      updatedAt: String(row.updated_at),
      username: String(row.username || "로컬 사용자"),
    };
  } finally {
    db.close();
  }
}

function uniqueExisting(paths) {
  const seen = new Set();

  return paths.filter((candidate) => {
    if (!candidate) {
      return false;
    }

    const normalized = path.resolve(candidate).toLowerCase();

    if (seen.has(normalized)) {
      return false;
    }

    seen.add(normalized);
    return fs.existsSync(candidate);
  });
}

function autoFindWalletDatabase({ appDataPath, homePath }) {
  const candidates = [
    path.join(appDataPath, "SD지갑", "data", "sdwallet.sqlite"),
    path.join(
      appDataPath,
      "sdwallet-desktop",
      "data",
      "sdwallet.sqlite",
    ),
    path.join(appDataPath, "SDWallet", "data", "sdwallet.sqlite"),
    path.join(homePath, "AppData", "Roaming", "SD지갑", "data", "sdwallet.sqlite"),
    path.join(homePath, "Downloads", "SDWallet_Stage7_Desktop", "data", "sdwallet.sqlite"),
    path.join(homePath, "Desktop", "SDWallet_Stage7_Desktop", "data", "sdwallet.sqlite"),
  ];

  for (const candidate of uniqueExisting(candidates)) {
    if (validateWalletDatabase(candidate).ok) {
      return candidate;
    }
  }

  try {
    const entries = fs.readdirSync(appDataPath, {
      withFileTypes: true,
    });

    for (const entry of entries) {
      if (!entry.isDirectory()) {
        continue;
      }

      const candidate = path.join(
        appDataPath,
        entry.name,
        "data",
        "sdwallet.sqlite",
      );

      if (
        fs.existsSync(candidate) &&
        validateWalletDatabase(candidate).ok
      ) {
        return candidate;
      }
    }
  } catch {
    return null;
  }

  return null;
}

module.exports = {
  autoFindWalletDatabase,
  readWalletAccounts,
  readWalletAccount,
  validateWalletDatabase,
};
