"use strict";

const PRIORITY_KEYS = [
  "goldPrice",
  "gold_price",
  "priceKrw",
  "price_krw",
  "purchasePrice",
  "purchase_price",
  "buyPrice",
  "buy_price",
  "price",
  "tradePrice",
  "trade_price",
  "close",
  "value",
  "krw",
];

function normalizeGoldPrice(price, unit) {
  const numeric = Number(price);

  if (!Number.isFinite(numeric) || numeric <= 0) {
    throw new Error("API에서 올바른 금 시세 숫자를 찾지 못했습니다.");
  }

  return unit === "gram" ? numeric : numeric / 3.75;
}

function getByJsonPath(value, jsonPath) {
  if (!jsonPath) {
    return undefined;
  }

  const segments = jsonPath
    .replace(/\[(\d+)\]/g, ".$1")
    .split(".")
    .map((segment) => segment.trim())
    .filter(Boolean);

  let current = value;

  for (const segment of segments) {
    if (
      current === null ||
      current === undefined ||
      !(segment in Object(current))
    ) {
      return undefined;
    }

    current = current[segment];
  }

  return current;
}

function parseNumeric(value) {
  if (typeof value === "number" && Number.isFinite(value)) {
    return value;
  }

  if (typeof value !== "string") {
    return NaN;
  }

  const cleaned = value
    .replace(/₩|KRW|원/gi, "")
    .replace(/,/g, "")
    .trim();

  const matched = cleaned.match(/-?\d+(?:\.\d+)?/);

  return matched ? Number(matched[0]) : NaN;
}

function findPriceRecursively(value, depth = 0) {
  if (depth > 8 || value === null || value === undefined) {
    return NaN;
  }

  const direct = parseNumeric(value);

  if (Number.isFinite(direct) && direct > 1000) {
    return direct;
  }

  if (Array.isArray(value)) {
    for (const item of value.slice(0, 20)) {
      const found = findPriceRecursively(item, depth + 1);

      if (Number.isFinite(found)) {
        return found;
      }
    }

    return NaN;
  }

  if (typeof value !== "object") {
    return NaN;
  }

  for (const key of PRIORITY_KEYS) {
    if (key in value) {
      const found = parseNumeric(value[key]);

      if (Number.isFinite(found) && found > 1000) {
        return found;
      }
    }
  }

  for (const [key, nested] of Object.entries(value).slice(0, 80)) {
    const lowered = key.toLowerCase();

    if (
      lowered.includes("time") ||
      lowered.includes("date") ||
      lowered.includes("year") ||
      lowered.includes("timestamp") ||
      lowered.includes("id")
    ) {
      continue;
    }

    const found = findPriceRecursively(nested, depth + 1);

    if (Number.isFinite(found)) {
      return found;
    }
  }

  return NaN;
}

async function fetchGoldPrice({
  url,
  jsonPath,
  sourceName,
  unit,
}) {
  let parsedUrl;

  try {
    parsedUrl = new URL(url);
  } catch {
    throw new Error("API 주소 형식이 올바르지 않습니다.");
  }

  if (!["http:", "https:"].includes(parsedUrl.protocol)) {
    throw new Error("API 주소는 http 또는 https만 사용할 수 있습니다.");
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 10_000);

  let response;

  try {
    response = await fetch(parsedUrl, {
      signal: controller.signal,
      headers: {
        Accept:
          "application/json, text/plain;q=0.9, */*;q=0.5",
        "User-Agent": "SDVault/1.0",
      },
    });
  } catch (error) {
    if (error.name === "AbortError") {
      throw new Error("금 시세 API 응답 시간이 초과되었습니다.");
    }

    throw new Error(`금 시세 API 연결 실패: ${error.message}`);
  } finally {
    clearTimeout(timeout);
  }

  if (!response.ok) {
    throw new Error(
      `금 시세 API 오류: HTTP ${response.status}`,
    );
  }

  const text = await response.text();
  let payload = text;

  try {
    payload = JSON.parse(text);
  } catch {
    // 일반 텍스트 또는 숫자 응답도 지원합니다.
  }

  const selected = jsonPath
    ? getByJsonPath(payload, jsonPath)
    : payload;

  const rawPrice = jsonPath
    ? parseNumeric(selected)
    : findPriceRecursively(selected);

  if (!Number.isFinite(rawPrice) || rawPrice <= 0) {
    throw new Error(
      jsonPath
        ? `JSON 경로 '${jsonPath}'에서 금 시세를 찾지 못했습니다.`
        : "API 응답에서 금 시세를 자동으로 찾지 못했습니다. 고급 설정에 JSON 경로를 입력하세요.",
    );
  }

  return {
    sourceName: sourceName || parsedUrl.hostname,
    sourceUrl: parsedUrl.toString(),
    rawPrice,
    unit,
    pricePerDonKrw:
      unit === "don" ? rawPrice : rawPrice * 3.75,
    pricePerGramKrw: normalizeGoldPrice(rawPrice, unit),
    fetchedAt: new Date().toISOString(),
  };
}

module.exports = {
  fetchGoldPrice,
  normalizeGoldPrice,
};
