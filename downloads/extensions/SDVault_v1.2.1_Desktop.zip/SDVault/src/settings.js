"use strict";

const crypto = require("node:crypto");
const fs = require("node:fs");
const path = require("node:path");
const { promisify } = require("node:util");

const scryptAsync = promisify(crypto.scrypt);

const DEFAULT_SETTINGS = Object.freeze({
  walletDatabasePath: "",
  selectedAccountId: "",

  goldApiUrl: "",
  goldApiJsonPath: "",
  goldSourceName: "사용자 지정 API",
  goldPriceUnit: "don",
  goldWeightUnit: "g",
  demoGoldPricePerDon: 826000,
  lastGoldPricePerGram: 0,
  lastGoldPriceAt: "",

  pinSalt: "",
  pinHash: "",
});

class SettingsStore {
  constructor(filePath) {
    this.filePath = filePath;
    this.data = this.#load();
  }

  #load() {
    try {
      if (!fs.existsSync(this.filePath)) {
        return { ...DEFAULT_SETTINGS };
      }

      const parsed = JSON.parse(
        fs.readFileSync(this.filePath, "utf-8"),
      );

      const normalized = {
        ...DEFAULT_SETTINGS,
        ...parsed,
      };

      if (!["g", "kg"].includes(normalized.goldWeightUnit)) {
        normalized.goldWeightUnit = "g";
      }

      return normalized;
    } catch {
      return { ...DEFAULT_SETTINGS };
    }
  }

  #save() {
    fs.mkdirSync(path.dirname(this.filePath), {
      recursive: true,
    });

    const temporaryPath = `${this.filePath}.tmp`;

    fs.writeFileSync(
      temporaryPath,
      JSON.stringify(this.data, null, 2),
      "utf-8",
    );

    fs.renameSync(temporaryPath, this.filePath);
  }

  get() {
    return { ...this.data };
  }

  getPublicSettings() {
    const {
      pinSalt,
      pinHash,
      ...publicSettings
    } = this.data;

    return {
      ...publicSettings,
      pinConfigured: Boolean(pinSalt && pinHash),
    };
  }

  update(patch) {
    const allowed = {
      walletDatabasePath:
        typeof patch.walletDatabasePath === "string"
          ? patch.walletDatabasePath
          : this.data.walletDatabasePath,

      selectedAccountId:
        typeof patch.selectedAccountId === "string"
          ? patch.selectedAccountId
          : this.data.selectedAccountId,

      goldApiUrl:
        typeof patch.goldApiUrl === "string"
          ? patch.goldApiUrl.trim()
          : this.data.goldApiUrl,

      goldApiJsonPath:
        typeof patch.goldApiJsonPath === "string"
          ? patch.goldApiJsonPath.trim()
          : this.data.goldApiJsonPath,

      goldSourceName:
        typeof patch.goldSourceName === "string"
          ? patch.goldSourceName.trim().slice(0, 60)
          : this.data.goldSourceName,

      goldPriceUnit:
        patch.goldPriceUnit === "gram" ||
        patch.goldPriceUnit === "don"
          ? patch.goldPriceUnit
          : this.data.goldPriceUnit,

      goldWeightUnit:
        ["g", "kg"].includes(patch.goldWeightUnit)
          ? patch.goldWeightUnit
          : this.data.goldWeightUnit,

      demoGoldPricePerDon:
        Number.isFinite(Number(patch.demoGoldPricePerDon))
          ? Math.max(1, Math.trunc(Number(patch.demoGoldPricePerDon)))
          : this.data.demoGoldPricePerDon,

      lastGoldPricePerGram:
        Number.isFinite(Number(patch.lastGoldPricePerGram))
          ? Math.max(0, Number(patch.lastGoldPricePerGram))
          : this.data.lastGoldPricePerGram,

      lastGoldPriceAt:
        typeof patch.lastGoldPriceAt === "string"
          ? patch.lastGoldPriceAt
          : this.data.lastGoldPriceAt,
    };

    this.data = {
      ...this.data,
      ...allowed,
    };

    this.#save();

    return this.getPublicSettings();
  }

  updatePublicSettings(patch) {
    return this.update(patch || {});
  }

  hasPin() {
    return Boolean(this.data.pinSalt && this.data.pinHash);
  }

  async setPin(pin) {
    const salt = crypto.randomBytes(16).toString("hex");
    const derived = Buffer.from(
      await scryptAsync(String(pin), salt, 64),
    );

    this.data.pinSalt = salt;
    this.data.pinHash = derived.toString("hex");
    this.#save();
  }

  async verifyPin(pin) {
    if (!this.hasPin()) {
      return false;
    }

    if (!/^\d{4}$/.test(String(pin))) {
      return false;
    }

    const expected = Buffer.from(this.data.pinHash, "hex");
    const actual = Buffer.from(
      await scryptAsync(
        String(pin),
        this.data.pinSalt,
        expected.length,
      ),
    );

    return (
      expected.length === actual.length &&
      crypto.timingSafeEqual(expected, actual)
    );
  }
}

module.exports = {
  SettingsStore,
};
