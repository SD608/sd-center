"use strict";

const http = require("node:http");

const port = 4090;
let basePricePerDon = 826000;

const server = http.createServer((request, response) => {
  if (request.url !== "/gold") {
    response.writeHead(404, {
      "Content-Type": "application/json; charset=utf-8",
    });
    response.end(
      JSON.stringify({
        error: "Not Found",
      }),
    );
    return;
  }

  const drift = Math.trunc((Math.random() - 0.5) * 1800);
  basePricePerDon = Math.max(
    500000,
    basePricePerDon + drift,
  );

  const payload = {
    source: "SD금고 테스트 API",
    unit: "KRW_PER_3_75G",
    data: {
      goldPrice: basePricePerDon,
      updatedAt: new Date().toISOString(),
    },
  };

  response.writeHead(200, {
    "Access-Control-Allow-Origin": "*",
    "Cache-Control": "no-store",
    "Content-Type": "application/json; charset=utf-8",
  });

  response.end(JSON.stringify(payload));
});

server.listen(port, "127.0.0.1", () => {
  console.log(
    `테스트 금 시세 API: http://127.0.0.1:${port}/gold`,
  );
  console.log("종료: Ctrl + C");
});
