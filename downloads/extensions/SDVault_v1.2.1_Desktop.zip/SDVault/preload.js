"use strict";

const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("sdVault", {
  getSettings: () => ipcRenderer.invoke("settings:get"),
  saveSettings: (patch) => ipcRenderer.invoke("settings:save", patch),

  autoDetectWallet: () => ipcRenderer.invoke("wallet:auto-detect"),
  chooseWalletDatabase: () =>
    ipcRenderer.invoke("wallet:choose-database"),
  listWalletAccounts: () =>
    ipcRenderer.invoke("wallet:list-accounts"),
  getWalletAccount: (accountId) =>
    ipcRenderer.invoke("wallet:get-account", accountId),

  getPinStatus: () => ipcRenderer.invoke("pin:status"),
  setupPin: (pin) => ipcRenderer.invoke("pin:setup", pin),
  verifyPin: (pin) => ipcRenderer.invoke("pin:verify", pin),
  changePin: (currentPin, newPin) =>
    ipcRenderer.invoke("pin:change", {
      currentPin,
      newPin,
    }),

  fetchGoldPrice: (config) =>
    ipcRenderer.invoke("gold:fetch", config),
});
