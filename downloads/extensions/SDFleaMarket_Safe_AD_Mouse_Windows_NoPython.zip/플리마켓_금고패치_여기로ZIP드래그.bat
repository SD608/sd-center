@echo off
chcp 65001 >nul
setlocal
if "%~1"=="" (
  echo.
  echo 플리마켓 전체 ZIP 파일을 이 BAT 파일 위로 끌어다 놓으세요.
  echo.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0patch_flea_safe_controls.ps1" "%~1"
if errorlevel 1 (
  echo.
  echo 패치에 실패했습니다. 위 오류 문구를 그대로 보내주세요.
) else (
  echo.
  echo 패치 완료. 원본 ZIP 옆에 _AD_Mouse.zip 파일이 생성되었습니다.
)
echo.
pause
