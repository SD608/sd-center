param(
  [Parameter(Mandatory=$true, Position=0)]
  [string]$TargetPath
)

$ErrorActionPreference = 'Stop'
$Marker = '// SD_SAFE_MOUSE_DIAL_V1'

function Apply-SafeDialPatch([string]$Text) {
  if ($Text.Contains($Marker)) { return $Text }

  $required = @(
    'function safeDialKeyDown(key)',
    'function updateSafeDial(dt, now)',
    'function renderSafe(session)',
    'id="safeDialAssembly"',
    'id="safeConfirmButton"'
  )
  $missing = @($required | Where-Object { -not $Text.Contains($_) })
  if ($missing.Count -gt 0) {
    throw ('금고 다이얼 코드 구조가 예상 버전과 다릅니다. 누락: ' + ($missing -join ', '))
  }

  $anchor = "let safeRattleAt = 0;`n"
  if (-not $Text.Contains($anchor)) { throw 'safeRattleAt 위치를 찾지 못했습니다.' }
  $Text = $Text.Replace($anchor, "let safeRattleAt = 0;`nlet safeDialDrag = null;`n")

  $oldUpdate = @'
function updateSafeDial(dt, now) {
  if (!safeMinigameActive()) return;
  const aHeld = keys.has("a") && safeHoldStartedAt.a > 0;
  const dHeld = keys.has("d") && safeHoldStartedAt.d > 0;
  if (aHeld === dHeld) return;

  const key = aHeld ? "a" : "d";
  const direction = aHeld ? -1 : 1;
  const heldFor = now - safeHoldStartedAt[key];
  if (heldFor < 180) return;

  const speed = heldFor < 450 ? 7 : 20;
  setSafeDialPosition(safeDialPosition + direction * speed * (dt / 1000), true);
  if (now - safeRattleAt >= 72) {
    playSafeDialRattle();
    safeRattleAt = now;
  }
}

'@

  if (-not $Text.Contains($oldUpdate)) { throw 'updateSafeDial 블록이 예상 버전과 다릅니다.' }

  $pointerCode = $oldUpdate + @'
// SD_SAFE_MOUSE_DIAL_V1
function safeDialPointerAngle(event, element) {
  const rect = element.getBoundingClientRect();
  const centerX = rect.left + rect.width / 2;
  const centerY = rect.top + rect.height / 2;
  return Math.atan2(event.clientY - centerY, event.clientX - centerX);
}

function startSafeDialDrag(event) {
  if (!safeMinigameActive()) return;
  if (event.pointerType === "mouse" && event.button !== 0) return;
  const surface = event.currentTarget;
  if (!surface) return;

  event.preventDefault();
  getAudioContext();
  safeDialDrag = {
    pointerId: event.pointerId,
    lastAngle: safeDialPointerAngle(event, surface),
  };
  surface.setPointerCapture?.(event.pointerId);
  surface.classList.add("dragging");
  surface.style.cursor = "grabbing";
}

function moveSafeDialDrag(event) {
  const drag = safeDialDrag;
  if (!drag || drag.pointerId !== event.pointerId || !safeMinigameActive()) return;
  const surface = event.currentTarget;
  if (!surface) return;

  event.preventDefault();
  const angle = safeDialPointerAngle(event, surface);
  let delta = angle - drag.lastAngle;
  if (delta > Math.PI) delta -= Math.PI * 2;
  else if (delta < -Math.PI) delta += Math.PI * 2;
  drag.lastAngle = angle;

  if (Math.abs(delta) < 0.0001) return;
  const dialDelta = -(delta / (Math.PI * 2)) * 100;
  setSafeDialPosition(safeDialPosition + dialDelta, true);

  const now = performance.now();
  if (now - safeRattleAt >= 72) {
    playSafeDialRattle();
    safeRattleAt = now;
  }
}

function stopSafeDialDrag(event) {
  const drag = safeDialDrag;
  if (!drag) return;
  if (event?.pointerId != null && drag.pointerId !== event.pointerId) return;

  safeDialDrag = null;
  const surface = event?.currentTarget || document.querySelector("#safeDialAssembly .safe-dial-shell");
  if (!surface) return;
  surface.classList.remove("dragging");
  surface.style.cursor = "grab";
  try {
    if (surface.hasPointerCapture?.(drag.pointerId)) {
      surface.releasePointerCapture(drag.pointerId);
    }
  } catch {
    // DOM 교체 순간 캡처가 먼저 풀려도 무시합니다.
  }
}

function bindSafeDialPointerControls() {
  const surface = document.querySelector("#safeDialAssembly .safe-dial-shell");
  if (!surface) return;
  surface.style.touchAction = "none";
  surface.style.userSelect = "none";
  surface.style.cursor = "grab";
  surface.addEventListener("pointerdown", startSafeDialDrag);
  surface.addEventListener("pointermove", moveSafeDialDrag);
  surface.addEventListener("pointerup", stopSafeDialDrag);
  surface.addEventListener("pointercancel", stopSafeDialDrag);
  surface.addEventListener("lostpointercapture", stopSafeDialDrag);
}

'@
  $Text = $Text.Replace($oldUpdate, $pointerCode)

  $resetAnchor = @'
  safeRattleAt = 0;
  modalSpaceAction = confirmSafeDial;
'@
  if (-not $Text.Contains($resetAnchor)) { throw 'renderSafe 초기화 위치를 찾지 못했습니다.' }
  $resetNew = @'
  safeRattleAt = 0;
  safeDialDrag = null;
  modalSpaceAction = confirmSafeDial;
'@
  $Text = $Text.Replace($resetAnchor, $resetNew)

  $Text = $Text.Replace(
    'A / D로 원하는 방향으로 돌리고, 걸리는 소리를 기억한 뒤 SPACE로 현재 번호를 확정하세요.',
    'A / D 또는 마우스로 다이얼을 직접 잡아 돌리고, 걸리는 소리를 기억한 뒤 SPACE로 현재 번호를 확정하세요.'
  )

  $oldHelp = @'
<div class="safe-control-grid"><span><kbd>A</kbd> 왼쪽</span><span><kbd>D</kbd> 오른쪽</span><span><kbd>SPACE</kbd> 확정</span></div>
        <p class="safe-no-limit">A/D를 짧게 누르면 1칸, 꾹 누르면 연속 회전합니다. 확정 횟수 제한은 없습니다.</p>
'@
  $newHelp = @'
<div class="safe-control-grid"><span><kbd>A</kbd> 왼쪽</span><span><kbd>D</kbd> 오른쪽</span><span><kbd>🖱</kbd> 잡고 회전</span><span><kbd>SPACE</kbd> 확정</span></div>
        <p class="safe-no-limit">A/D를 짧게 누르면 1칸, 꾹 누르면 연속 회전합니다. 마우스는 다이얼을 잡은 채 원을 그리듯 돌리면 됩니다. 확정 횟수 제한은 없습니다.</p>
'@
  if ($Text.Contains($oldHelp)) { $Text = $Text.Replace($oldHelp, $newHelp) }

  $bindAnchor = @'
  renderSafePins();
  $("#safeConfirmButton").addEventListener("click", confirmSafeDial);
}
'@
  if (-not $Text.Contains($bindAnchor)) { throw '금고 렌더링 후 이벤트 연결 위치를 찾지 못했습니다.' }
  $bindNew = @'
  renderSafePins();
  bindSafeDialPointerControls();
  $("#safeConfirmButton").addEventListener("click", confirmSafeDial);
}
'@
  $Text = $Text.Replace($bindAnchor, $bindNew)

  return $Text
}

function Write-Utf8NoBom([string]$Path, [string]$Text) {
  $enc = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($Path, $Text, $enc)
}

$resolved = (Resolve-Path -LiteralPath $TargetPath).Path
$ext = [System.IO.Path]::GetExtension($resolved).ToLowerInvariant()

if ($ext -eq '.zip') {
  Add-Type -AssemblyName System.IO.Compression.FileSystem
  $dir = Split-Path -Parent $resolved
  $stem = [System.IO.Path]::GetFileNameWithoutExtension($resolved)
  $out = Join-Path $dir ($stem + '_AD_Mouse.zip')
  $temp = Join-Path ([System.IO.Path]::GetTempPath()) ('SDFleaPatch_' + [Guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $temp | Out-Null
  try {
    [System.IO.Compression.ZipFile]::ExtractToDirectory($resolved, $temp)
    $app = Get-ChildItem -LiteralPath $temp -Recurse -File -Filter 'app.js' | Where-Object {
      ($_.FullName.Replace('\','/')).EndsWith('/public/app.js')
    } | Select-Object -First 1
    if (-not $app) { throw 'ZIP 안에서 public/app.js를 찾지 못했습니다. 정상 플리마켓 전체 ZIP인지 확인하세요.' }

    $text = [System.IO.File]::ReadAllText($app.FullName, [System.Text.Encoding]::UTF8)
    $patched = Apply-SafeDialPatch $text
    Write-Utf8NoBom $app.FullName $patched

    if (Test-Path -LiteralPath $out) { Remove-Item -LiteralPath $out -Force }
    [System.IO.Compression.ZipFile]::CreateFromDirectory($temp, $out, [System.IO.Compression.CompressionLevel]::Optimal, $false)
    Write-Host ''
    Write-Host '완료:' -ForegroundColor Green
    Write-Host $out
  }
  finally {
    if (Test-Path -LiteralPath $temp) { Remove-Item -LiteralPath $temp -Recurse -Force }
  }
}
else {
  $text = [System.IO.File]::ReadAllText($resolved, [System.Text.Encoding]::UTF8)
  $patched = Apply-SafeDialPatch $text
  $dir = Split-Path -Parent $resolved
  $stem = [System.IO.Path]::GetFileNameWithoutExtension($resolved)
  $out = Join-Path $dir ($stem + '.AD_Mouse.js')
  Write-Utf8NoBom $out $patched
  Write-Host ''
  Write-Host '완료:' -ForegroundColor Green
  Write-Host $out
}
