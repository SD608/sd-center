"use strict";

(() => {
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const lerp = (a, b, t) => a + (b - a) * t;

  function create(options = {}) {
    const canvas = options.canvas;
    if (!canvas) throw new Error("BankChaseGame requires a canvas");
    const ctx = canvas.getContext("2d", { alpha: false });
    const safeCount = Math.max(1, Math.trunc(Number(options.safeCount || 1)));
    const risk = 0.32; // 보통 난이도 고정: 기존 금고 2개 수준
    const chaseTuning = {
      targetDistance: Math.round(850 + risk * 400),
      spawnMin: Math.max(0.62, 1.45 - risk * 0.48),
      spawnRange: Math.max(0.34, 0.66 - risk * 0.16),
      busChance: clamp(0.06 + risk * 0.10, 0.06, 0.22),
      rockChance: clamp(0.20 + risk * 0.035, 0.20, 0.255),
      damageMultiplier: 1 + risk * 0.35,
    };
    const targetDistance = Number(options.targetDistance || chaseTuning.targetDistance);
    const cruiseSpeedKmh = 100;
    const maxSpeedKmh = 150;
    const accelerationKmhPerSec = 18;
    const decelerationKmhPerSec = 22;

    let active = false;
    let finished = false;
    let lastFrame = 0;
    let raf = 0;
    let width = 0;
    let height = 0;
    let dpr = 1;
    let lane = 1;
    let visualLane = 1;
    let steering = 0;
    let durability = 100;
    let distance = 0;
    let spawnTimer = 0.8;
    let roadScroll = 0;
    let shake = 0;
    let flash = 0;
    let obstacles = [];
    let obstacleSerial = 0;
    let revPulse = 0;
    let throttleHeld = false;
    let speedKmh = cruiseSpeedKmh;

    let audioCtx = options.audioContext || null;
    let engineOsc = null;
    let engineHarmonic = null;
    let engineFilter = null;
    let engineGain = null;
    let roadSource = null;
    let roadFilter = null;
    let roadGain = null;
    let audioRunning = false;

    const laneCenters = [-1, 0, 1];


    function ensureAudioContext() {
      if (audioCtx) {
        if (audioCtx.state === "suspended") audioCtx.resume().catch(() => {});
        return audioCtx;
      }
      const AudioCtor = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtor) return null;
      audioCtx = new AudioCtor();
      if (audioCtx.state === "suspended") audioCtx.resume().catch(() => {});
      return audioCtx;
    }

    function startVehicleAudio() {
      const ctxAudio = ensureAudioContext();
      if (!ctxAudio || audioRunning) return;
      audioRunning = true;

      const master = ctxAudio.createGain();
      master.gain.value = 0.92;
      master.connect(ctxAudio.destination);

      engineGain = ctxAudio.createGain();
      engineGain.gain.setValueAtTime(0.0001, ctxAudio.currentTime);
      engineGain.gain.exponentialRampToValueAtTime(0.046, ctxAudio.currentTime + 0.18);
      engineFilter = ctxAudio.createBiquadFilter();
      engineFilter.type = "lowpass";
      engineFilter.frequency.value = 520;
      engineFilter.Q.value = 0.8;
      engineFilter.connect(engineGain).connect(master);

      engineOsc = ctxAudio.createOscillator();
      engineOsc.type = "sawtooth";
      engineOsc.frequency.value = 79;
      engineOsc.connect(engineFilter);
      engineOsc.start();

      engineHarmonic = ctxAudio.createOscillator();
      engineHarmonic.type = "triangle";
      engineHarmonic.frequency.value = 158;
      const harmonicGain = ctxAudio.createGain();
      harmonicGain.gain.value = 0.33;
      engineHarmonic.connect(harmonicGain).connect(engineFilter);
      engineHarmonic.start();

      const seconds = 2.2;
      const length = Math.max(1, Math.floor(ctxAudio.sampleRate * seconds));
      const buffer = ctxAudio.createBuffer(1, length, ctxAudio.sampleRate);
      const data = buffer.getChannelData(0);
      let last = 0;
      for (let i = 0; i < length; i += 1) {
        const white = Math.random() * 2 - 1;
        last = last * 0.86 + white * 0.14;
        data[i] = last * 0.9 + white * 0.1;
      }
      roadSource = ctxAudio.createBufferSource();
      roadSource.buffer = buffer;
      roadSource.loop = true;
      roadFilter = ctxAudio.createBiquadFilter();
      roadFilter.type = "bandpass";
      roadFilter.frequency.value = 270;
      roadFilter.Q.value = 0.52;
      roadGain = ctxAudio.createGain();
      roadGain.gain.setValueAtTime(0.0001, ctxAudio.currentTime);
      roadGain.gain.exponentialRampToValueAtTime(0.026, ctxAudio.currentTime + 0.24);
      roadSource.connect(roadFilter).connect(roadGain).connect(master);
      roadSource.start();
    }

    function updateVehicleAudio(dt) {
      if (!audioRunning || !audioCtx || !engineOsc || !engineHarmonic) return;
      revPulse = Math.max(0, revPulse - dt * 2.4);
      const throttleRev = throttleHeld ? 1 : revPulse;
      const speedRev = clamp((speedKmh - cruiseSpeedKmh) / (maxSpeedKmh - cruiseSpeedKmh), 0, 1);
      const subtleRunningVariation = (Math.sin(distance * 0.035) + 1) * 0.5;
      const rev = clamp(subtleRunningVariation * 0.08 + throttleRev * 0.62 + speedRev * 0.30, 0, 1);
      const now = audioCtx.currentTime;
      const base = 79 + rev * 48;
      engineOsc.frequency.setTargetAtTime(base, now, throttleHeld ? 0.045 : 0.11);
      engineHarmonic.frequency.setTargetAtTime(base * 2.02, now, throttleHeld ? 0.045 : 0.11);
      engineFilter?.frequency.setTargetAtTime(500 + rev * 360, now, 0.08);
      engineGain?.gain.setTargetAtTime(0.043 + rev * 0.031, now, 0.07);
      roadFilter?.frequency.setTargetAtTime(250 + Math.abs(steering) * 55, now, 0.12);
      roadGain?.gain.setTargetAtTime(0.025 + Math.abs(steering) * 0.005, now, 0.12);
    }

    function stopVehicleAudio() {
      if (!audioRunning) return;
      audioRunning = false;
      if (!audioCtx) return;
      const now = audioCtx.currentTime;
      try {
        engineGain?.gain.cancelScheduledValues(now);
        engineGain?.gain.setTargetAtTime(0.0001, now, 0.06);
        roadGain?.gain.cancelScheduledValues(now);
        roadGain?.gain.setTargetAtTime(0.0001, now, 0.06);
      } catch {}
      const stopLater = (node) => {
        if (!node) return;
        try { node.stop(now + 0.22); } catch {}
      };
      stopLater(engineOsc);
      stopLater(engineHarmonic);
      stopLater(roadSource);
      engineOsc = null;
      engineHarmonic = null;
      engineFilter = null;
      engineGain = null;
      roadSource = null;
      roadFilter = null;
      roadGain = null;
    }

    function resize() {
      const rect = canvas.getBoundingClientRect();
      dpr = Math.min(2, window.devicePixelRatio || 1);
      width = Math.max(1, rect.width);
      height = Math.max(1, rect.height);
      canvas.width = Math.round(width * dpr);
      canvas.height = Math.round(height * dpr);
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    }

    function laneToX(laneValue, yProgress = 1) {
      const roadHalfNear = width * 0.46;
      const roadHalfFar = width * 0.08;
      const roadHalf = lerp(roadHalfFar, roadHalfNear, yProgress);
      return width / 2 + laneCenters[0] * 0 + laneValue * (roadHalf / 1.55);
    }

    function playerScreenX() {
      // 1인칭이지만 차선 변경이 눈에 보이도록 보닛/대시보드도 실제 차선 중심을 따라 이동시킨다.
      // 완전히 차선 중심까지 보내면 화면 밖으로 너무 많이 빠지므로 약 78%만 반영한다.
      const laneX = laneToX(visualLane - 1, 1);
      return lerp(width / 2, laneX, 0.78);
    }

    function obstacleHitPlayer(obstacle) {
      const playerLane = clamp(Math.round(visualLane), 0, 2);
      return playerLane >= obstacle.laneStart && playerLane < obstacle.laneStart + obstacle.span;
    }

    function spawnObstacle() {
      const roll = Math.random();
      let type = "police";
      let span = 1;
      let laneStart = Math.floor(Math.random() * 3);
      let baseDamage = 20;
      if (roll < chaseTuning.busChance) {
        type = "bus";
        span = 2;
        laneStart = Math.random() < 0.5 ? 0 : 1;
        baseDamage = 35;
      } else if (roll < chaseTuning.busChance + chaseTuning.rockChance) {
        type = "rock";
        baseDamage = 18;
      }
      const damage = Math.round(baseDamage * chaseTuning.damageMultiplier);
      obstacles.push({
        id: ++obstacleSerial,
        type,
        laneStart,
        span,
        damage,
        depth: 1.04,
        hit: false,
      });
    }

    function moveLane(direction) {
      if (!active || finished) return;
      const next = clamp(lane + direction, 0, 2);
      if (next === lane) return;
      lane = next;
      steering = direction * 1.15;
      revPulse = Math.max(revPulse, 0.88);
      ensureAudioContext();
      options.onLaneChange?.(lane);
    }

    function handleKey(event) {
      if (!active || finished) return false;
      const key = String(event.key || "").toLowerCase();
      if ((key === "a" || key === "arrowleft") && !event.repeat) {
        moveLane(-1);
        return true;
      }
      if ((key === "d" || key === "arrowright") && !event.repeat) {
        moveLane(1);
        return true;
      }
      if (key === "w" || key === "arrowup") {
        throttleHeld = true;
        revPulse = 1;
        ensureAudioContext();
        return true;
      }
      return ["a", "d", "arrowleft", "arrowright", "s", "arrowdown", "shift", " "].includes(key);
    }

    function handleKeyUp(event) {
      if (!active || finished) return false;
      const key = String(event.key || "").toLowerCase();
      if (key === "w" || key === "arrowup") {
        throttleHeld = false;
        return true;
      }
      return false;
    }

    function update(dt) {
      if (!active || finished) return;

      const targetSpeed = throttleHeld ? maxSpeedKmh : cruiseSpeedKmh;
      if (speedKmh < targetSpeed) speedKmh = Math.min(targetSpeed, speedKmh + accelerationKmhPerSec * dt);
      else if (speedKmh > targetSpeed) speedKmh = Math.max(targetSpeed, speedKmh - decelerationKmhPerSec * dt);

      const speedMps = speedKmh / 3.6;
      const speedFactor = speedKmh / 120;
      distance += speedMps * dt;
      roadScroll = (roadScroll + dt * 1.45 * speedFactor) % 1;
      visualLane = lerp(visualLane, lane, 1 - Math.exp(-dt * 7.5));
      steering = lerp(steering, 0, 1 - Math.exp(-dt * 5));
      shake = Math.max(0, shake - dt * 2.6);
      flash = Math.max(0, flash - dt * 3.1);
      updateVehicleAudio(dt);

      spawnTimer -= dt;
      if (spawnTimer <= 0 && distance < targetDistance - 85) {
        spawnObstacle();
        // 운반 중인 금고 수가 많을수록 경찰 대응이 강해져 장애물 간격이 짧아진다.
        spawnTimer = chaseTuning.spawnMin + Math.random() * chaseTuning.spawnRange;
      }

      for (const obstacle of obstacles) {
        obstacle.depth -= dt * 0.34 * (speedKmh / 120);
        if (!obstacle.hit && obstacle.depth <= 0.09) {
          obstacle.hit = true;
          if (obstacleHitPlayer(obstacle)) {
            durability = Math.max(0, durability - obstacle.damage);
            shake = 1;
            flash = 1;
            options.onImpact?.({ type: obstacle.type, damage: obstacle.damage, durability });
            options.onDurability?.(durability);
            if (durability <= 0) {
              finish(false);
              return;
            }
          }
        }
      }
      obstacles = obstacles.filter((obstacle) => obstacle.depth > -0.13);
      options.onDistance?.(distance, targetDistance);
      if (distance >= targetDistance) finish(true);
    }

    function drawBackground() {
      const sky = ctx.createLinearGradient(0, 0, 0, height * 0.58);
      sky.addColorStop(0, "#07101b");
      sky.addColorStop(0.55, "#1c3349");
      sky.addColorStop(1, "#8d7c70");
      ctx.fillStyle = sky;
      ctx.fillRect(0, 0, width, height);

      const horizon = height * 0.27;
      ctx.fillStyle = "#101720";
      for (let i = 0; i < 18; i += 1) {
        const bw = width / 18 + 6;
        const bx = i * width / 18 - 4;
        const bh = 22 + ((i * 47) % 70);
        ctx.fillRect(bx, horizon - bh, bw, bh);
        ctx.fillStyle = i % 3 === 0 ? "#d4c37b" : "#344a5d";
        for (let wy = horizon - bh + 9; wy < horizon - 6; wy += 13) {
          for (let wx = bx + 7; wx < bx + bw - 5; wx += 12) ctx.fillRect(wx, wy, 3, 4);
        }
        ctx.fillStyle = "#101720";
      }

      const roadLeftNear = width * 0.04;
      const roadRightNear = width * 0.96;
      const roadLeftFar = width * 0.44;
      const roadRightFar = width * 0.56;
      ctx.beginPath();
      ctx.moveTo(roadLeftFar, horizon);
      ctx.lineTo(roadRightFar, horizon);
      ctx.lineTo(roadRightNear, height);
      ctx.lineTo(roadLeftNear, height);
      ctx.closePath();
      const road = ctx.createLinearGradient(0, horizon, 0, height);
      road.addColorStop(0, "#30343a");
      road.addColorStop(1, "#171a1f");
      ctx.fillStyle = road;
      ctx.fill();

      ctx.strokeStyle = "rgba(236,240,244,.82)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(roadLeftFar, horizon);
      ctx.lineTo(roadLeftNear, height);
      ctx.moveTo(roadRightFar, horizon);
      ctx.lineTo(roadRightNear, height);
      ctx.stroke();

      for (const laneDivider of [-0.5, 0.5]) {
        for (let i = 0; i < 11; i += 1) {
          const t0 = ((i / 11 + roadScroll) % 1);
          const t1 = Math.min(1, t0 + 0.055 + t0 * 0.045);
          if (t0 > 0.92) continue;
          const y0 = horizon + Math.pow(t0, 1.7) * (height - horizon);
          const y1 = horizon + Math.pow(t1, 1.7) * (height - horizon);
          const x0 = laneToX(laneDivider, t0);
          const x1 = laneToX(laneDivider, t1);
          ctx.strokeStyle = "rgba(238,238,226,.78)";
          ctx.lineWidth = 1 + t0 * 5;
          ctx.beginPath();
          ctx.moveTo(x0, y0);
          ctx.lineTo(x1, y1);
          ctx.stroke();
        }
      }

      ctx.fillStyle = "#20252b";
      ctx.beginPath();
      ctx.moveTo(0, horizon + 20);
      ctx.lineTo(roadLeftFar, horizon);
      ctx.lineTo(roadLeftNear, height);
      ctx.lineTo(0, height);
      ctx.closePath();
      ctx.fill();
      ctx.beginPath();
      ctx.moveTo(width, horizon + 20);
      ctx.lineTo(roadRightFar, horizon);
      ctx.lineTo(roadRightNear, height);
      ctx.lineTo(width, height);
      ctx.closePath();
      ctx.fill();
    }

    function obstacleGeometry(obstacle) {
      const p = clamp(1 - obstacle.depth, 0, 1.08);
      const y = height * 0.27 + Math.pow(p, 1.72) * (height * 0.7);
      const centerLane = obstacle.laneStart + (obstacle.span - 1) / 2 - 1;
      const x = laneToX(centerLane, p);
      const laneWidth = lerp(width * 0.04, width * 0.29, p);
      const w = laneWidth * obstacle.span * (obstacle.type === "bus" ? 0.92 : 0.62);
      const h = w * (obstacle.type === "bus" ? 1.02 : obstacle.type === "rock" ? 0.55 : 0.68);
      return { p, x, y, w, h };
    }

    function drawPolice(obstacle, g) {
      const { x, y, w, h, p } = g;
      ctx.save();
      ctx.translate(x, y);
      ctx.globalAlpha = clamp(0.25 + p * 1.1, 0, 1);
      ctx.fillStyle = "rgba(0,0,0,.36)";
      ctx.beginPath();
      ctx.ellipse(0, h * 0.08, w * 0.58, h * 0.16, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#e8edf1";
      ctx.fillRect(-w * 0.46, -h * 0.55, w * 0.92, h * 0.55);
      ctx.fillStyle = "#172433";
      ctx.fillRect(-w * 0.34, -h * 0.75, w * 0.68, h * 0.28);
      ctx.fillStyle = "#2b6ca3";
      ctx.fillRect(-w * 0.46, -h * 0.2, w * 0.92, h * 0.16);
      ctx.fillStyle = "#f33750";
      ctx.fillRect(-w * 0.23, -h * 0.87, w * 0.18, h * 0.08);
      ctx.fillStyle = "#3a8fff";
      ctx.fillRect(w * 0.05, -h * 0.87, w * 0.18, h * 0.08);
      ctx.fillStyle = "#14191e";
      ctx.fillRect(-w * 0.38, -h * 0.04, w * 0.18, h * 0.13);
      ctx.fillRect(w * 0.20, -h * 0.04, w * 0.18, h * 0.13);
      ctx.restore();
    }

    function drawRock(obstacle, g) {
      const { x, y, w, h, p } = g;
      ctx.save();
      ctx.translate(x, y);
      ctx.globalAlpha = clamp(0.28 + p * 1.08, 0, 1);
      ctx.fillStyle = "rgba(0,0,0,.38)";
      ctx.beginPath();
      ctx.ellipse(0, h * 0.08, w * 0.58, h * 0.18, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = "#6f645a";
      ctx.strokeStyle = "#3b3632";
      ctx.lineWidth = Math.max(1, w * 0.035);
      ctx.beginPath();
      ctx.moveTo(-w * 0.5, 0);
      ctx.lineTo(-w * 0.34, -h * 0.62);
      ctx.lineTo(-w * 0.08, -h * 0.92);
      ctx.lineTo(w * 0.24, -h * 0.76);
      ctx.lineTo(w * 0.48, -h * 0.32);
      ctx.lineTo(w * 0.42, 0);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    function drawBus(obstacle, g) {
      const { x, y, w, h, p } = g;
      ctx.save();
      ctx.translate(x, y);
      ctx.globalAlpha = clamp(0.22 + p * 1.12, 0, 1);
      ctx.fillStyle = "rgba(0,0,0,.4)";
      ctx.beginPath();
      ctx.ellipse(0, h * 0.05, w * 0.55, h * 0.12, 0, 0, Math.PI * 2);
      ctx.fill();
      const grad = ctx.createLinearGradient(0, -h, 0, 0);
      grad.addColorStop(0, "#d8d2c6");
      grad.addColorStop(1, "#8e9293");
      ctx.fillStyle = grad;
      ctx.fillRect(-w * 0.49, -h * 0.94, w * 0.98, h * 0.94);
      ctx.fillStyle = "#172733";
      ctx.fillRect(-w * 0.42, -h * 0.82, w * 0.84, h * 0.3);
      ctx.fillStyle = "#b9343f";
      ctx.fillRect(-w * 0.49, -h * 0.22, w * 0.98, h * 0.12);
      ctx.fillStyle = "#101418";
      ctx.fillRect(-w * 0.40, -h * 0.08, w * 0.2, h * 0.11);
      ctx.fillRect(w * 0.20, -h * 0.08, w * 0.2, h * 0.11);
      ctx.restore();
    }

    function drawObstacles() {
      const ordered = [...obstacles].sort((a, b) => b.depth - a.depth);
      for (const obstacle of ordered) {
        const g = obstacleGeometry(obstacle);
        if (obstacle.type === "police") drawPolice(obstacle, g);
        else if (obstacle.type === "rock") drawRock(obstacle, g);
        else drawBus(obstacle, g);
      }
    }

    function drawCockpit() {
      const bikeCenterX = playerScreenX();
      const laneDelta = visualLane - lane;
      const bodyLean = clamp(laneDelta * 0.065, -0.06, 0.06);
      const forkTopY = height * 0.79;
      const forkBottomY = height * 0.99;
      const barY = height * 0.885;
      const barHalf = width * 0.17;
      const handleTurn = steering * 0.45;

      ctx.save();
      ctx.translate(bikeCenterX, 0);
      ctx.rotate(bodyLean);

      ctx.strokeStyle = "#858f99";
      ctx.lineWidth = Math.max(3, width * 0.004);
      ctx.beginPath();
      ctx.moveTo(-width * 0.018, forkTopY);
      ctx.lineTo(-width * 0.02, forkBottomY);
      ctx.moveTo(width * 0.018, forkTopY);
      ctx.lineTo(width * 0.02, forkBottomY);
      ctx.stroke();

      ctx.save();
      ctx.translate(0, barY);
      ctx.rotate(handleTurn);
      ctx.strokeStyle = "#14181d";
      ctx.lineWidth = Math.max(6, width * 0.0068);
      ctx.lineCap = "round";
      ctx.beginPath();
      ctx.moveTo(-barHalf, 0);
      ctx.quadraticCurveTo(0, -height * 0.02, barHalf, 0);
      ctx.stroke();
      ctx.fillStyle = "#090c0f";
      ctx.fillRect(-barHalf - width * 0.017, -height * 0.012, width * 0.034, height * 0.052);
      ctx.fillRect(barHalf - width * 0.017, -height * 0.012, width * 0.034, height * 0.052);
      ctx.strokeStyle = "#8794a1";
      ctx.lineWidth = Math.max(2, width * 0.0027);
      ctx.beginPath();
      ctx.moveTo(-barHalf * 0.8, -5); ctx.lineTo(-barHalf * 1.05, -height * 0.065);
      ctx.moveTo(barHalf * 0.8, -5); ctx.lineTo(barHalf * 1.05, -height * 0.065);
      ctx.stroke();
      ctx.fillStyle = "rgba(196,226,244,.13)";
      ctx.beginPath();
      ctx.ellipse(-barHalf * 1.08, -height * 0.071, width * 0.029, height * 0.024, -0.18, 0, Math.PI * 2);
      ctx.ellipse(barHalf * 1.08, -height * 0.071, width * 0.029, height * 0.024, 0.18, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // 원형 디지털 계기판 — 사용자가 보여준 계기판의 구성감을 반영하되 게임용으로 단순화.
      const gaugeX = 0;
      const gaugeY = height * 0.815;
      const gaugeR = Math.min(width, height) * 0.105;
      ctx.save();
      ctx.translate(gaugeX, gaugeY);
      ctx.fillStyle = "#05080b";
      ctx.beginPath(); ctx.arc(0, 0, gaugeR * 1.12, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = "#252c32";
      ctx.lineWidth = gaugeR * 0.11;
      ctx.stroke();
      const glass = ctx.createRadialGradient(-gaugeR*.2,-gaugeR*.35,gaugeR*.08,0,0,gaugeR);
      glass.addColorStop(0,"#142229"); glass.addColorStop(.55,"#071015"); glass.addColorStop(1,"#020507");
      ctx.fillStyle = glass;
      ctx.beginPath(); ctx.arc(0,0,gaugeR*.94,0,Math.PI*2); ctx.fill();

      const arcStart = Math.PI * 0.84;
      const arcEnd = Math.PI * 2.16;
      const segments = 16;
      for (let i=0;i<segments;i+=1) {
        const t=i/(segments-1);
        const a=lerp(arcStart,arcEnd,t);
        ctx.strokeStyle = i < 12 ? "#8ff7f5" : "#f13b43";
        ctx.lineWidth = gaugeR * .075;
        ctx.beginPath();
        ctx.arc(0,0,gaugeR*.76,a,a+(arcEnd-arcStart)/segments*.62);
        ctx.stroke();
      }

      ctx.textAlign="center";
      ctx.fillStyle="#cbd8de";
      ctx.font=`800 ${Math.max(8,gaugeR*.12)}px Segoe UI, sans-serif`;
      ctx.fillText("남은 거리",0,-gaugeR*.46);
      ctx.fillStyle="#f4fbff";
      ctx.font=`900 ${Math.max(11,gaugeR*.17)}px Consolas, monospace`;
      const remainingMeters = Math.max(0, Math.ceil(targetDistance - distance));
      ctx.fillText(`${remainingMeters.toLocaleString("ko-KR")} m`,0,-gaugeR*.27);
      ctx.strokeStyle="#7ef2ef";
      ctx.lineWidth=Math.max(1,gaugeR*.015);
      ctx.beginPath();ctx.moveTo(-gaugeR*.62,-gaugeR*.12);ctx.lineTo(gaugeR*.62,-gaugeR*.12);ctx.stroke();

      ctx.fillStyle="#f4f7ff";
      ctx.font=`900 ${Math.max(24,gaugeR*.48)}px Consolas, monospace`;
      ctx.fillText(String(Math.round(speedKmh)),0,gaugeR*.28);
      ctx.fillStyle="#d5e6eb";
      ctx.font=`800 ${Math.max(9,gaugeR*.13)}px Segoe UI, sans-serif`;
      ctx.fillText("km/h",gaugeR*.44,gaugeR*.35);
      ctx.strokeStyle="#7ef2ef";
      ctx.beginPath();ctx.moveTo(-gaugeR*.62,gaugeR*.43);ctx.lineTo(gaugeR*.62,gaugeR*.43);ctx.stroke();

      ctx.fillStyle=throttleHeld?"#ffbd55":"#75f28c";
      ctx.font=`900 ${Math.max(8,gaugeR*.11)}px Segoe UI, sans-serif`;
      ctx.textAlign="left";ctx.fillText(throttleHeld?"BOOST":"RUN",-gaugeR*.56,gaugeR*.66);
      ctx.fillStyle="#bdcbd1";ctx.textAlign="center";ctx.fillText("6",0,gaugeR*.66);
      ctx.fillStyle="#ff5962";ctx.textAlign="right";ctx.fillText("ABS",gaugeR*.56,gaugeR*.66);
      ctx.restore();

      ctx.strokeStyle = "rgba(122,221,255,.2)";
      ctx.lineWidth = Math.max(1, width * 0.0015);
      ctx.beginPath(); ctx.moveTo(0, forkTopY + 5); ctx.lineTo(0, height); ctx.stroke();
      ctx.restore();
    }

    function draw() {
      ctx.save();
      if (shake > 0) ctx.translate((Math.random() - 0.5) * shake * 18, (Math.random() - 0.5) * shake * 10);
      drawBackground();
      drawObstacles();
      drawCockpit();
      ctx.restore();
      if (flash > 0) {
        ctx.fillStyle = `rgba(255,65,72,${flash * 0.24})`;
        ctx.fillRect(0, 0, width, height);
      }
    }

    function frame(now) {
      if (!active) return;
      if (!lastFrame) lastFrame = now;
      const dt = Math.min(0.05, Math.max(0, (now - lastFrame) / 1000));
      lastFrame = now;
      update(dt);
      draw();
      if (active) raf = requestAnimationFrame(frame);
    }

    function finish(success) {
      if (finished) return;
      finished = true;
      active = false;
      cancelAnimationFrame(raf);
      stopVehicleAudio();
      options.onFinish?.({ success: Boolean(success), durability, distance: Math.min(distance, targetDistance), targetDistance });
    }

    function start() {
      cancelAnimationFrame(raf);
      active = true;
      finished = false;
      lastFrame = 0;
      lane = 1;
      visualLane = 1;
      steering = 0;
      durability = 100;
      distance = 0;
      spawnTimer = chaseTuning.spawnMin + 0.2;
      roadScroll = 0;
      shake = 0;
      flash = 0;
      obstacles = [];
      revPulse = 0;
      throttleHeld = false;
      speedKmh = cruiseSpeedKmh;
      resize();
      startVehicleAudio();
      options.onDurability?.(durability);
      options.onDistance?.(distance, targetDistance);
      raf = requestAnimationFrame(frame);
    }

    function stop() {
      active = false;
      throttleHeld = false;
      cancelAnimationFrame(raf);
      stopVehicleAudio();
    }

    return {
      start,
      stop,
      resize,
      handleKey,
      handleKeyUp,
      moveLeft: () => moveLane(-1),
      moveRight: () => moveLane(1),
      isActive: () => active,
      getState: () => ({ durability, distance, targetDistance, lane, speedKmh, cruiseSpeedKmh, maxSpeedKmh, throttleHeld, safeCount, risk, chaseTuning: { ...chaseTuning } }),
    };
  }

  window.BankChaseGame = { create };
})();
