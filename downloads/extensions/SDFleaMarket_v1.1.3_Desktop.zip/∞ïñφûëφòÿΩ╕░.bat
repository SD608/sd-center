@echo off
chcp 65001 >nul
cd /d "%~dp0"
where npm.cmd >nul 2>nul
if errorlevel 1 (
  echo [오류] Node.js/npm을 찾을 수 없습니다.
  echo public\index.html을 직접 열어도 브라우저 모드로 실행할 수 있습니다.
  pause
  exit /b 1
)
if not exist "node_modules\electron\package.json" (
  echo Electron 설치 중...
  call npm.cmd install
  if errorlevel 1 (
    echo [오류] npm install 실패
    pause
    exit /b 1
  )
)
call npm.cmd start
