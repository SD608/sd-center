"use strict";

// SDLINK_FLEA_ITEM_BRIDGE_V131
const fs = require("node:fs");
const path = require("node:path");

function unique(values) {
  const seen = new Set();
  const out = [];
  for (const value of values) {
    if (!value) continue;
    const resolved = path.resolve(String(value));
    const key = resolved.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(resolved);
  }
  return out;
}

function candidateFiles(fileName) {
  return unique(
    [process.env.APPDATA, process.env.LOCALAPPDATA]
      .filter(Boolean)
      .map((root) => path.join(root, "SD608", "integration", fileName))
  );
}

function readJson(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, "utf8"));
  } catch {
    return null;
  }
}

function normalizeItems(items) {
  if (!Array.isArray(items)) return [];
  return items.slice(0, 5000).map((item) => ({
    local_item_id: String(item?.local_item_id || "").slice(0, 120),
    box_id: String(item?.box_id || "").slice(0, 120),
    name: String(item?.name || "").slice(0, 120),
    tier: String(item?.tier || "worn").toLowerCase(),
    original_value: Math.max(0, Math.trunc(Number(item?.original_value || 0))),
    current_value: Math.max(0, Math.trunc(Number(item?.current_value ?? item?.original_value ?? 0))),
    condition_percent: Math.max(0, Math.min(100, Number(item?.condition_percent ?? 100))),
    acquired_at: String(item?.acquired_at || ""),
    source: String(item?.source || "PC 플리마켓").slice(0, 160),
  })).filter((item) => item.local_item_id && item.name);
}

function readFleaInventorySnapshot({ userId = "" } = {}) {
  let newest = null;
  let unbound = null;
  for (const filePath of candidateFiles("flea-inventory.json")) {
    if (!fs.existsSync(filePath)) continue;
    const value = readJson(filePath);
    if (!value || typeof value !== "object") continue;
    const snapshotUserId = String(value.userId || "");
    const timestamp = Date.parse(value.updatedAt || "") || fs.statSync(filePath).mtimeMs || 0;
    const entry = {
      found: true,
      sourcePath: filePath,
      timestamp,
      userId: snapshotUserId,
      snapshotKey: String(value.snapshotKey || ""),
      items: normalizeItems(value.items),
      updatedAt: String(value.updatedAt || ""),
    };
    if (!snapshotUserId) {
      if (!unbound || timestamp > unbound.timestamp) unbound = entry;
      continue;
    }
    if (userId && snapshotUserId !== String(userId)) continue;
    if (!newest || timestamp > newest.timestamp) newest = entry;
  }
  if (newest) return newest;
  if (unbound) return { ...unbound, found: false, unbound: true, reason: "snapshot-user-not-bound" };
  return { found: false, sourcePath: "", timestamp: 0, userId: "", snapshotKey: "", items: [], updatedAt: "" };
}

function writeFleaInventoryResult({
  sourcePath = "",
  userId = "",
  snapshotKey = "",
  ownedLocalItemIds = [],
  syncedCount = 0,
} = {}) {
  const resultPaths = [];
  if (sourcePath) resultPaths.push(path.join(path.dirname(sourcePath), "flea-inventory-result.json"));
  resultPaths.push(...candidateFiles("flea-inventory-result.json"));
  const targets = unique(resultPaths);
  if (!targets.length) return null;

  const payload = {
    schemaVersion: 1,
    sourceApp: "sdlink-desktop",
    sourceVersion: "1.3.1",
    userId: String(userId || ""),
    snapshotKey: String(snapshotKey || ""),
    ownedLocalItemIds: Array.isArray(ownedLocalItemIds) ? ownedLocalItemIds.map(String) : [],
    syncedCount: Math.max(0, Math.trunc(Number(syncedCount || 0))),
    updatedAt: new Date().toISOString(),
  };

  const filePath = targets[0];
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  const temp = `${filePath}.${process.pid}.tmp`;
  fs.writeFileSync(temp, JSON.stringify(payload, null, 2) + "\n", { encoding: "utf8", mode: 0o600 });
  fs.renameSync(temp, filePath);
  return { ...payload, filePath };
}

module.exports = {
  readFleaInventorySnapshot,
  writeFleaInventoryResult,
};
