"use strict";

// SDLINK_LOGISTICS_BRIDGE_V130
// SD 물류센터 v1.1.0이 내보내는 비밀정보 없는 로컬 진행도 스냅샷을 읽습니다.
const fs = require("node:fs");
const path = require("node:path");

function unique(values) {
  const seen = new Set();
  const out = [];
  for (const value of values) {
    if (!value) continue;
    const resolved = path.resolve(String(value));
    const key = resolved.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(resolved);
  }
  return out;
}

function candidates(walletDatabasePath = "") {
  const walletDir = walletDatabasePath ? path.dirname(path.resolve(walletDatabasePath)) : "";
  const roots = unique([
    process.env.APPDATA,
    process.env.LOCALAPPDATA,
    walletDir,
    walletDir && path.dirname(walletDir),
    walletDir && path.dirname(path.dirname(walletDir)),
  ]);
  const files = [];
  for (const root of roots) {
    files.push(path.join(root, "SDLogisticsCenter", "sd-logistics-progress.json"));
    files.push(path.join(root, "SD 물류센터", "sd-logistics-progress.json"));
    files.push(path.join(root, "sd-logistics-progress.json"));
  }
  return unique(files);
}

function number(value) {
  const n = Number(value);
  return Number.isFinite(n) ? Math.max(0, n) : 0;
}

function normalize(raw) {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
  const vehicleTypes = Array.isArray(raw.vehicleTypes)
    ? [...new Set(raw.vehicleTypes.map((v) => String(v || "").trim()).filter(Boolean))].slice(0, 16)
    : [];
  return {
    logisticsRep: number(raw.logisticsRep ?? raw.logistics_rep),
    headquartersLevel: Math.trunc(number(raw.headquartersLevel ?? raw.headquarters_level)),
    completedContracts: Math.trunc(number(raw.completedContracts)),
    logisticsRevenue: number(raw.logisticsRevenue),
    xlargeCompleted: Math.trunc(number(raw.xlargeCompleted)),
    warehouseOwned: Boolean(raw.warehouseOwned),
    fleetCount: Math.trunc(number(raw.fleetCount)),
    vehicleTypes,
    pcProgressUpdatedAt: String(raw.updatedAt || ""),
    pcProgressSource: "sd-logistics-center-desktop",
  };
}

function readLogisticsProgress({ walletDatabasePath = "", accountId = "" } = {}) {
  const found = [];
  for (const file of candidates(walletDatabasePath)) {
    if (!fs.existsSync(file)) continue;
    try {
      const raw = JSON.parse(fs.readFileSync(file, "utf8"));
      const linkedAccountId = String(raw?.wallet?.selectedAccountId || "");
      if (linkedAccountId && accountId && linkedAccountId !== String(accountId)) continue;
      const state = normalize(raw);
      if (!state) continue;
      const timestamp = Date.parse(raw.updatedAt || "") || fs.statSync(file).mtimeMs || 0;
      found.push({ found: true, sourcePath: file, timestamp, state });
    } catch {
      // 손상되거나 잠시 쓰는 중인 파일은 다음 자동 동기화에서 다시 읽습니다.
    }
  }
  found.sort((a, b) => b.timestamp - a.timestamp);
  return found[0] || { found: false, sourcePath: "", timestamp: 0, state: null };
}

module.exports = { readLogisticsProgress };
