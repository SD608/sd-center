"use strict";

const path = require("node:path");
const { isSdCenterUrl, openSdCenter } = require("./src/open-center");
const {
  app,
  BrowserWindow,
  dialog,
  ipcMain,
  session,
} = require("electron");

const { SettingsStore } = require("./src/settings");
const {
  applyGameResult,
  autoFindWalletDatabase,
  getAccount,
  getRecentTransactions,
  listAccounts,
  validateWalletDatabase,
} = require("./src/wallet-database");
const { GameEngine } = require("./src/game-engine");
const { SdLinkGameClient } = require("./src/sdlink-game-client");

const singleInstanceLock =
  app.requestSingleInstanceLock();

if (!singleInstanceLock) {
  app.quit();
}

let mainWindow = null;
let settingsStore = null;
let onlineGameClient = null;
const gameEngine = new GameEngine();
const onlineOddEvenRounds = new Map();
const ONLINE_ACCOUNT_ID = "sd-online";

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1280,
    height: 900,
    minWidth: 980,
    minHeight: 720,
    title: "SD홀짝",
    backgroundColor: "#080b12",
    autoHideMenuBar: true,
    show: false,
    icon: path.join(
      __dirname,
      "public",
      "icons",
      "icon-512.png",
    ),

    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      nodeIntegration: false,
      contextIsolation: true,
      sandbox: true,
      webSecurity: true,
      allowRunningInsecureContent: false,
    },
  });

  mainWindow.webContents.setWindowOpenHandler(
    () => ({ action: "deny" }),
  );

  mainWindow.webContents.on(
    "will-attach-webview",
    (event) => event.preventDefault(),
  );

  mainWindow.webContents.on(
    "will-navigate",
    (event, navigationUrl) => {
    if (isSdCenterUrl(navigationUrl)) {
      event.preventDefault();
      openSdCenter(app);
      return;
    }

      try {
        const target = new URL(navigationUrl);

        if (target.protocol !== "file:") {
          event.preventDefault();
        }
      } catch {
        event.preventDefault();
      }
    },
  );

  mainWindow.once("ready-to-show", () => {
    mainWindow.show();
  });

  mainWindow.loadFile(
    path.join(__dirname, "public", "index.html"),
  );
}

function currentWalletPath() {
  return settingsStore.get().walletDatabasePath;
}

function registerIpcHandlers() {
  ipcMain.handle("settings:get", () => {
    return settingsStore.get();
  });

  ipcMain.handle("settings:save", (event, patch) => {
    return settingsStore.update(patch);
  });

  ipcMain.handle("wallet:auto-detect", async () => {
    try {
      await onlineGameClient.state();
      settingsStore.update({ walletDatabasePath: "SD Link Online", selectedAccountId: ONLINE_ACCOUNT_ID });
      return { found: true, path: "SD Link Online" };
    } catch (error) {
      return { found: false, error: error.message };
    }
  });

  ipcMain.handle("wallet:choose-database", async () => {
    try {
      await onlineGameClient.state();
      settingsStore.update({ walletDatabasePath: "SD Link Online", selectedAccountId: ONLINE_ACCOUNT_ID });
      return { canceled: false, ok: true, path: "SD Link Online" };
    } catch (error) {
      return { canceled: false, ok: false, error: error.message };
    }
  });

  ipcMain.handle("wallet:list-accounts", async () => {
    try {
      const state = await onlineGameClient.state();
      settingsStore.update({ walletDatabasePath: "SD Link Online", selectedAccountId: ONLINE_ACCOUNT_ID });
      return { connected: true, databasePath: "SD Link Online", accounts: [state.account] };
    } catch (error) {
      return { connected: false, databasePath: "SD Link Online", accounts: [], error: error.message };
    }
  });

  ipcMain.handle("wallet:get-account", async () => {
    try {
      const state = await onlineGameClient.state();
      return {
        connected: true,
        account: state.account,
        transactions: state.normalizedTransactions,
      };
    } catch (error) {
      return { connected: false, account: null, transactions: [], error: error.message };
    }
  });

  ipcMain.handle("game:start", async (event, payload) => {
    try {
      const state = await onlineGameClient.state();
      const round = gameEngine.startRound({
        accountId: ONLINE_ACCOUNT_ID,
        betAmountKrw: payload?.betAmountKrw,
        multiplier: payload?.multiplier,
        allIn: payload?.allIn === true,
        balance: state.account.balance,
      });
      settingsStore.update({
        walletDatabasePath: "SD Link Online",
        selectedAccountId: ONLINE_ACCOUNT_ID,
        selectedBetKrw: Number(payload?.betAmountKrw),
        betMode: round.allIn ? "all-in" : "fixed",
        selectedMultiplier: round.multiplier,
      });
      return { ok: true, ...round };
    } catch (error) {
      return { ok: false, error: error.message };
    }
  });

  ipcMain.handle("game:stop", async (event, roundId) => {
    const localRoundId = String(roundId || "");
    try {
      const local = gameEngine.stopRound(localRoundId);
      const server = await onlineGameClient.rpc("start_sd_odd_even", {
        p_wager: local.stake,
        p_request_id: onlineGameClient.uuid(),
        p_platform: "windows",
      });
      const serverRoundId = String(server?.round_id || "");
      if (!serverRoundId) throw new Error("온라인 홀짝 라운드 번호를 받지 못했습니다.");
      onlineOddEvenRounds.set(localRoundId, serverRoundId);
      return {
        ok: true,
        ...local,
        balanceAfterWager: Math.trunc(Number(server?.balance_after_wager || 0)),
      };
    } catch (error) {
      gameEngine.cancelRound(localRoundId);
      onlineOddEvenRounds.delete(localRoundId);
      return { ok: false, error: error.message };
    }
  });

  ipcMain.handle("game:resolve", async (event, payload) => {
    const localRoundId = String(payload?.roundId || "");
    try {
      const serverRoundId = onlineOddEvenRounds.get(localRoundId);
      if (!serverRoundId) throw new Error("온라인 홀짝 라운드 정보를 찾지 못했습니다.");
      const data = await onlineGameClient.rpc("finish_sd_odd_even", {
        p_round_id: serverRoundId,
        p_choice: payload?.choice,
      });
      onlineOddEvenRounds.delete(localRoundId);
      gameEngine.finishRound(localRoundId);
      const wager = Math.trunc(Number(data?.wager || 0));
      const won = Boolean(data?.won);
      const now = new Date().toISOString();
      return {
        ok: true,
        dice: [Number(data?.die1 || 1), Number(data?.die2 || 1)],
        sum: Number(data?.total || 0),
        parity: String(data?.parity || "odd"),
        choice: String(data?.choice || payload?.choice || "odd"),
        won,
        stake: wager,
        multiplier: 1,
        balance: Math.trunc(Number(data?.balance_after || 0)),
        transaction: {
          id: String(data?.round_id || serverRoundId),
          type: won ? "deposit" : "withdraw",
          memo: "홀짝 게임",
          amount: wager,
          createdAt: now,
        },
      };
    } catch (error) {
      if (localRoundId) gameEngine.cancelRound(localRoundId);
      onlineOddEvenRounds.delete(localRoundId);
      return { ok: false, error: error.message };
    }
  });
}

app.whenReady().then(() => {
  settingsStore = new SettingsStore(
    path.join(
      app.getPath("userData"),
      "settings.json",
    ),
  );
  onlineGameClient = new SdLinkGameClient();
  settingsStore.update({ walletDatabasePath: "SD Link Online", selectedAccountId: ONLINE_ACCOUNT_ID });

  registerIpcHandlers();

  session.defaultSession.setPermissionRequestHandler(
    (webContents, permission, callback) => {
      callback(false);
    },
  );

  createWindow();
});

app.on("second-instance", () => {
  if (!mainWindow) {
    return;
  }

  if (mainWindow.isMinimized()) {
    mainWindow.restore();
  }

  mainWindow.show();
  mainWindow.focus();
});

app.on("window-all-closed", () => {
  app.quit();
});
