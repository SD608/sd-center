"use strict";

/* SD종합센터 UI Preview v2.3.0-preview.1
 * 기존 v2.2.7의 IPC/앱 관리 로직은 그대로 사용하고 렌더러 UI만 교체합니다.
 */

const PREVIEW_LAYOUT_KEY = "sd-center-ui-preview-home-v1";
const PREVIEW_RECENT_KEY = "sd-center-ui-preview-recent-v1";

const preview = {
  view: "home",
  editing: false,
  layout: [],
  recent: [],
  activeFolderId: "",
  libraryFilter: "",
  bootSelectPending: true,
};

const previewElements = {
  homePanel: document.getElementById("previewHomePanel"),
  updatesPanel: document.getElementById("previewUpdatesPanel"),
  homeGrid: document.getElementById("previewHomeGrid"),
  recentGrid: document.getElementById("previewRecentGrid"),
  homeHint: document.getElementById("previewHomeHint"),
  updateList: document.getElementById("previewUpdateList"),
  updateSummary: document.getElementById("previewUpdateSummary"),
  updateNavCount: document.getElementById("previewUpdateNavCount"),
  search: document.getElementById("globalSearchInput"),
  newFolderButton: document.getElementById("previewNewFolderButton"),
  editHomeButton: document.getElementById("previewEditHomeButton"),
  addAppNav: document.getElementById("previewAddAppNav"),
  checkUpdatesButton: document.getElementById("checkUpdatesButton"),
  updateAllButton: document.getElementById("updateAllButton"),
  previewCheckUpdatesButton: document.getElementById("previewCheckUpdatesButton"),
  folderBackdrop: document.getElementById("previewFolderBackdrop"),
  folderTitle: document.getElementById("previewFolderTitle"),
  folderCount: document.getElementById("previewFolderCount"),
  folderGrid: document.getElementById("previewFolderGrid"),
  folderClose: document.getElementById("previewCloseFolderButton"),
  folderRename: document.getElementById("previewRenameFolderButton"),
  folderDelete: document.getElementById("previewDeleteFolderButton"),
};

// v2.2.7의 renderOverview가 새 버튼 상태도 함께 갱신하도록 연결합니다.
elements.checkUpdatesButton = previewElements.checkUpdatesButton;
elements.updateAllButton = previewElements.updateAllButton;

function previewEscape(value) {
  return escapeHtml(value);
}

function readJsonStorage(key, fallback) {
  try {
    const value = JSON.parse(localStorage.getItem(key));
    return value ?? fallback;
  } catch {
    return fallback;
  }
}

function writeJsonStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // 로컬 저장 실패는 실행 기능에 영향을 주지 않습니다.
  }
}

function appIconMarkup(app, className = "") {
  return `<span class="${className}"><img src="${previewEscape(iconPath(app))}" alt="" draggable="false"></span>`;
}

function defaultLayoutForApps(apps) {
  const economy = [];
  const games = [];
  const loose = [];

  for (const app of apps) {
    const token = `${app.id || ""} ${app.name || ""}`.toLowerCase();
    if (/물류|플리마켓|광부|금고|bitcoin|비트코인|wallet|지갑|miner|vault|logistics|flea/.test(token)) {
      economy.push(app.id);
    } else if (/슬롯|홀짝|묵찌빠|sta|slot|odd|mukjippa/.test(token)) {
      games.push(app.id);
    } else {
      loose.push(app.id);
    }
  }

  const layout = [];
  if (economy.length) layout.push({ type: "folder", id: "economy", name: "경제", apps: economy });
  if (games.length) layout.push({ type: "folder", id: "games", name: "게임", apps: games });
  for (const id of loose) layout.push({ type: "app", id });
  return layout;
}

function syncPreviewLayout() {
  const validIds = new Set(state.apps.map((app) => app.id));
  let layout = Array.isArray(preview.layout) ? preview.layout : [];

  if (layout.length === 0) {
    layout = defaultLayoutForApps(state.apps);
  }

  const seen = new Set();
  const cleaned = [];

  for (const raw of layout) {
    if (!raw || typeof raw !== "object") continue;
    if (raw.type === "folder") {
      const apps = [];
      for (const id of Array.isArray(raw.apps) ? raw.apps : []) {
        if (validIds.has(id) && !seen.has(id)) {
          seen.add(id);
          apps.push(id);
        }
      }
      cleaned.push({
        type: "folder",
        id: String(raw.id || `folder-${Date.now()}-${cleaned.length}`),
        name: String(raw.name || "새 폴더"),
        apps,
      });
      continue;
    }
    if (raw.type === "app" && validIds.has(raw.id) && !seen.has(raw.id)) {
      seen.add(raw.id);
      cleaned.push({ type: "app", id: raw.id });
    }
  }

  for (const app of state.apps) {
    if (!seen.has(app.id)) cleaned.push({ type: "app", id: app.id });
  }

  preview.layout = cleaned;
  writeJsonStorage(PREVIEW_LAYOUT_KEY, preview.layout);
}

function findApp(id) {
  return state.apps.find((app) => app.id === id);
}

function findFolder(id) {
  return preview.layout.find((item) => item.type === "folder" && item.id === id);
}

function isAppInLayout(id) {
  return preview.layout.some((item) =>
    item.type === "app" ? item.id === id : Array.isArray(item.apps) && item.apps.includes(id),
  );
}

function saveRecent(id) {
  if (!id) return;
  preview.recent = [id, ...preview.recent.filter((item) => item !== id)].slice(0, 8);
  writeJsonStorage(PREVIEW_RECENT_KEY, preview.recent);
}

function renderPreviewRecent() {
  const apps = preview.recent
    .map(findApp)
    .filter(Boolean)
    .slice(0, 4);

  if (!apps.length) {
    previewElements.recentGrid.innerHTML = `
      <div class="preview-empty-recent">앱을 실행하면 최근 실행 목록에 표시됩니다.</div>
    `;
    return;
  }

  previewElements.recentGrid.innerHTML = apps.map((app) => `
    <button class="preview-recent-card" type="button" data-preview-app="${previewEscape(app.id)}">
      ${appIconMarkup(app, "preview-recent-icon")}
      <span class="preview-recent-name">${previewEscape(app.name)}</span>
      <span class="preview-recent-meta">${app.running ? '<i class="preview-running-dot"></i>실행 중' : "계속하기"}</span>
    </button>
  `).join("");
}

function homeTile(item, index) {
  if (item.type === "folder") {
    return `
      <button class="preview-home-tile${preview.editing ? " is-editing" : ""}" type="button"
        draggable="${preview.editing ? "true" : "false"}" data-preview-index="${index}" data-preview-folder="${previewEscape(item.id)}">
        <span class="preview-home-icon folder">▦</span>
        <div class="preview-home-name">${previewEscape(item.name)}</div>
        <div class="preview-home-sub">${item.apps.length}개 앱</div>
      </button>
    `;
  }

  const app = findApp(item.id);
  if (!app) return "";
  const updateBadge = app.updateRequired ? "!" : app.updateAvailable ? "UP" : "";
  return `
    <button class="preview-home-tile${preview.editing ? " is-editing" : ""}" type="button"
      draggable="${preview.editing ? "true" : "false"}" data-preview-index="${index}" data-preview-app="${previewEscape(app.id)}">
      ${updateBadge ? `<span class="preview-home-badge">${updateBadge}</span>` : ""}
      ${appIconMarkup(app, "preview-home-icon")}
      <div class="preview-home-name">${previewEscape(app.name)}</div>
      <div class="preview-home-sub">${app.running ? '<i class="preview-running-dot"></i>실행 중' : previewEscape(app.version || "설치됨")}</div>
    </button>
  `;
}

function renderPreviewHome() {
  syncPreviewLayout();
  renderPreviewRecent();
  previewElements.homeGrid.innerHTML = preview.layout.map(homeTile).join("");
  previewElements.homeHint.textContent = preview.editing
    ? "앱을 폴더 위로 끌어 넣거나 순서를 바꿀 수 있습니다."
    : "앱을 눌러 실행";
  previewElements.editHomeButton.textContent = preview.editing ? "편집 완료" : "홈 편집";

  previewElements.homeGrid.querySelectorAll(".preview-home-tile").forEach((tile) => {
    tile.addEventListener("dragstart", (event) => {
      if (!preview.editing) return event.preventDefault();
      event.dataTransfer.effectAllowed = "move";
      event.dataTransfer.setData("text/plain", tile.dataset.previewIndex || "");
    });
    tile.addEventListener("dragover", (event) => {
      if (!preview.editing) return;
      event.preventDefault();
      tile.classList.add("is-drop-target");
    });
    tile.addEventListener("dragleave", () => tile.classList.remove("is-drop-target"));
    tile.addEventListener("drop", (event) => {
      if (!preview.editing) return;
      event.preventDefault();
      tile.classList.remove("is-drop-target");
      const from = Number(event.dataTransfer.getData("text/plain"));
      const to = Number(tile.dataset.previewIndex);
      if (!Number.isInteger(from) || !Number.isInteger(to) || !preview.layout[from] || !preview.layout[to]) return;
      const source = preview.layout[from];
      const target = preview.layout[to];

      if (source.type === "app" && target.type === "folder") {
        target.apps.push(source.id);
        preview.layout.splice(from, 1);
      } else if (from !== to) {
        const [moved] = preview.layout.splice(from, 1);
        const nextIndex = from < to ? to - 1 : to;
        preview.layout.splice(nextIndex, 0, moved);
      }
      writeJsonStorage(PREVIEW_LAYOUT_KEY, preview.layout);
      renderPreviewHome();
    });
  });
}

function renderPreviewFolder() {
  const folder = findFolder(preview.activeFolderId);
  if (!folder) {
    previewElements.folderBackdrop.classList.add("hidden");
    return;
  }
  const apps = folder.apps.map(findApp).filter(Boolean);
  previewElements.folderTitle.textContent = folder.name;
  previewElements.folderCount.textContent = `${apps.length}개 앱`;
  previewElements.folderGrid.innerHTML = apps.length ? apps.map((app) => `
    <button class="preview-folder-app" type="button" data-preview-app="${previewEscape(app.id)}">
      ${preview.editing ? `<span class="preview-folder-remove" data-preview-remove-from-folder="${previewEscape(app.id)}" title="홈으로 빼기">↖</span>` : ""}
      ${appIconMarkup(app, "preview-folder-app-icon")}
      <div class="preview-folder-app-name">${previewEscape(app.name)}</div>
    </button>
  `).join("") : '<div class="preview-up-to-date">빈 폴더입니다. 홈 편집에서 앱을 끌어 넣어보세요.</div>';
}

function openPreviewFolder(id) {
  preview.activeFolderId = id;
  renderPreviewFolder();
  previewElements.folderBackdrop.classList.remove("hidden");
}

function closePreviewFolder() {
  previewElements.folderBackdrop.classList.add("hidden");
  preview.activeFolderId = "";
}

function createPreviewFolder() {
  const raw = window.prompt("새 폴더 이름", "새 폴더");
  if (raw == null) return;
  const name = raw.trim() || "새 폴더";
  const id = `folder-${Date.now()}`;
  preview.layout.push({ type: "folder", id, name, apps: [] });
  writeJsonStorage(PREVIEW_LAYOUT_KEY, preview.layout);
  renderPreviewHome();
  showToast(`${name} 폴더를 만들었습니다.`);
}

function renamePreviewFolder() {
  const folder = findFolder(preview.activeFolderId);
  if (!folder) return;
  const raw = window.prompt("폴더 이름 변경", folder.name);
  if (raw == null) return;
  folder.name = raw.trim() || folder.name;
  writeJsonStorage(PREVIEW_LAYOUT_KEY, preview.layout);
  renderPreviewHome();
  renderPreviewFolder();
}

function deletePreviewFolder() {
  const index = preview.layout.findIndex((item) => item.type === "folder" && item.id === preview.activeFolderId);
  if (index < 0) return;
  const folder = preview.layout[index];
  const moveBack = folder.apps.map((id) => ({ type: "app", id }));
  preview.layout.splice(index, 1, ...moveBack);
  writeJsonStorage(PREVIEW_LAYOUT_KEY, preview.layout);
  closePreviewFolder();
  renderPreviewHome();
  showToast("폴더를 삭제했습니다. 앱은 홈으로 이동했습니다.");
}

function removeAppFromFolder(id) {
  const folder = findFolder(preview.activeFolderId);
  if (!folder) return;
  folder.apps = folder.apps.filter((appId) => appId !== id);
  if (!isAppInLayout(id)) preview.layout.push({ type: "app", id });
  writeJsonStorage(PREVIEW_LAYOUT_KEY, preview.layout);
  renderPreviewFolder();
  renderPreviewHome();
}

function libraryStatus(app) {
  if (app.updateRequired) return { cls: "update", text: `필수 v${app.requiredVersion}` };
  if (app.updateAvailable) return { cls: "update", text: `v${app.latestVersion} 업데이트` };
  if (app.running) return { cls: "running", text: "실행 중" };
  return { cls: "", text: "설치됨" };
}

// 기존 appGrid 이벤트 위임을 그대로 사용할 수 있도록 버튼 class를 유지합니다.
installedAppCard = function previewInstalledAppCard(app) {
  const busy = state.busyIds.has(app.id);
  const status = libraryStatus(app);
  const launchLabel = app.updateRequired ? "필수 업데이트" : app.running ? "열기" : "실행";
  return `
    <article class="app-card preview-library-row" data-id="${previewEscape(app.id)}" data-search="${previewEscape(`${app.name} ${app.description || ""}`.toLowerCase())}">
      ${appIconMarkup(app, "preview-library-app-icon")}
      <div class="preview-library-copy">
        <div class="preview-library-name-row">
          <strong>${previewEscape(app.name)}</strong>
          <span class="preview-library-version">v${previewEscape(app.version || "-")}</span>
        </div>
        <div class="preview-library-description">${previewEscape(app.description || app.improvement || "SD 확장팩")}</div>
      </div>
      <div class="preview-library-status ${status.cls}">${status.text}</div>
      <div class="card-actions">
        <button class="favorite-button${app.favorite ? " is-favorite" : ""}" type="button" title="즐겨찾기">${app.favorite ? "★" : "☆"}</button>
        ${app.updateAvailable ? `<button class="button button-secondary update-button" type="button" ${busy ? "disabled" : ""}>업데이트</button>` : ""}
        <button class="button button-primary launch-button" type="button" ${busy ? "disabled" : ""}>${busy ? "처리 중" : launchLabel}</button>
        ${app.running ? `<button class="button button-danger terminate-button" type="button" ${busy ? "disabled" : ""}>종료</button>` : ""}
        <button class="button button-secondary folder-button" type="button">폴더</button>
        <button class="button button-delete delete-button" type="button" ${busy ? "disabled" : ""}>제거</button>
      </div>
    </article>
  `;
};

function applyLibraryFilter() {
  const q = preview.libraryFilter.trim().toLowerCase();
  elements.appGrid.querySelectorAll(".preview-library-row").forEach((row) => {
    row.classList.toggle("hidden", Boolean(q) && !String(row.dataset.search || "").includes(q));
  });
}

function renderPreviewUpdates() {
  const updates = state.apps.filter((app) => app.updateAvailable || app.updateRequired);
  const count = updates.length;
  previewElements.updateNavCount.textContent = String(count);
  previewElements.updateNavCount.classList.toggle("hidden", count === 0);

  previewElements.updateSummary.innerHTML = `
    <strong>${count}</strong>
    <div>
      <h2>${count ? `업데이트 ${count}개` : "모든 앱이 최신 상태입니다"}</h2>
      <p>${count ? "업데이트가 필요한 확장팩을 확인한 뒤 개별 또는 한 번에 적용할 수 있습니다." : "설치된 확장팩에서 새 업데이트가 확인되지 않았습니다."}</p>
    </div>
    ${count ? '<button class="preview-button" type="button" data-preview-update-all>모두 업데이트</button>' : ""}
  `;

  previewElements.updateList.innerHTML = count ? updates.map((app) => `
    <div class="preview-update-row" data-preview-update-id="${previewEscape(app.id)}">
      ${appIconMarkup(app, "preview-update-icon")}
      <div>
        <div class="preview-update-name">${previewEscape(app.name)}</div>
        <div class="preview-update-version">현재 v${previewEscape(app.version || "-")} ${app.latestVersion ? `→ v${previewEscape(app.latestVersion)}` : ""}</div>
        <div class="preview-update-notes">${previewEscape(app.updateNotes || (app.updateRequired ? "필수 업데이트가 필요합니다." : "새 버전을 설치할 수 있습니다."))}</div>
      </div>
      <button class="preview-button preview-button-primary" type="button" data-preview-update-app="${previewEscape(app.id)}">업데이트</button>
    </div>
  `).join("") : '<div class="preview-up-to-date">지금 설치할 업데이트가 없습니다.</div>';
}

function refreshPreviewNav() {
  document.querySelectorAll(".preview-nav[data-preview-view]").forEach((button) => {
    button.classList.toggle("active", button.dataset.previewView === preview.view);
  });
}

function setPreviewView(view) {
  const next = ["home", "library", "store", "updates", "removed"].includes(view) ? view : "home";
  preview.view = next;
  state.activeTab = next === "library" ? "installed" : next;

  previewElements.homePanel.classList.toggle("hidden", next !== "home");
  elements.installedPanel.classList.toggle("hidden", next !== "library");
  elements.storePanel.classList.toggle("hidden", next !== "store");
  previewElements.updatesPanel.classList.toggle("hidden", next !== "updates");
  elements.removedPanel.classList.toggle("hidden", next !== "removed");

  refreshPreviewNav();
  if (next === "store" && state.storeApps.length === 0 && !state.storeLoading) void loadStore(true);
  if (next === "home") renderPreviewHome();
  if (next === "updates") renderPreviewUpdates();
  if (next === "library") applyLibraryFilter();
}

// 기존 코드에서 selectTab("installed")를 부르는 흐름과 호환합니다.
selectTab = function previewSelectTab(tab) {
  if (tab === "store") return setPreviewView("store");
  if (tab === "removed") return setPreviewView("removed");
  if (tab === "installed") {
    if (preview.bootSelectPending) {
      preview.bootSelectPending = false;
      return setPreviewView("home");
    }
    return setPreviewView("library");
  }
  return setPreviewView("home");
};

const originalLaunchApp = launchApp;
launchApp = async function previewLaunchApp(id) {
  saveRecent(id);
  renderPreviewRecent();
  const result = await originalLaunchApp(id);
  renderPreviewHome();
  return result;
};

const originalRenderApps = renderApps;
renderApps = function previewRenderApps() {
  originalRenderApps();
  renderPreviewHome();
  renderPreviewUpdates();
  applyLibraryFilter();
};

const originalRenderStore = renderStore;
renderStore = function previewRenderStore() {
  originalRenderStore();
  refreshPreviewNav();
};

preview.layout = readJsonStorage(PREVIEW_LAYOUT_KEY, []);
preview.recent = readJsonStorage(PREVIEW_RECENT_KEY, []);

// 새 UI 전용 이벤트
for (const button of document.querySelectorAll(".preview-nav[data-preview-view]")) {
  button.addEventListener("click", () => setPreviewView(button.dataset.previewView));
}

previewElements.addAppNav.addEventListener("click", () => elements.addAppButton.click());
previewElements.newFolderButton.addEventListener("click", createPreviewFolder);
previewElements.editHomeButton.addEventListener("click", () => {
  preview.editing = !preview.editing;
  renderPreviewHome();
  if (!previewElements.folderBackdrop.classList.contains("hidden")) renderPreviewFolder();
  showToast(preview.editing ? "홈 편집을 시작했습니다." : "홈 배치를 저장했습니다.");
});

previewElements.homeGrid.addEventListener("click", (event) => {
  const folder = event.target.closest("[data-preview-folder]");
  if (folder) {
    openPreviewFolder(folder.dataset.previewFolder);
    return;
  }
  const app = event.target.closest("[data-preview-app]");
  if (app && !preview.editing) void launchApp(app.dataset.previewApp);
});

previewElements.recentGrid.addEventListener("click", (event) => {
  const app = event.target.closest("[data-preview-app]");
  if (app) void launchApp(app.dataset.previewApp);
});

previewElements.folderGrid.addEventListener("click", (event) => {
  const remove = event.target.closest("[data-preview-remove-from-folder]");
  if (remove) {
    event.preventDefault();
    event.stopPropagation();
    removeAppFromFolder(remove.dataset.previewRemoveFromFolder);
    return;
  }
  const app = event.target.closest("[data-preview-app]");
  if (app && !preview.editing) {
    closePreviewFolder();
    void launchApp(app.dataset.previewApp);
  }
});

previewElements.folderClose.addEventListener("click", closePreviewFolder);
previewElements.folderBackdrop.addEventListener("click", (event) => {
  if (event.target === previewElements.folderBackdrop) closePreviewFolder();
});
previewElements.folderRename.addEventListener("click", renamePreviewFolder);
previewElements.folderDelete.addEventListener("click", deletePreviewFolder);

previewElements.checkUpdatesButton.addEventListener("click", () => void checkAppUpdates());
previewElements.updateAllButton.addEventListener("click", () => void updateAllApps());
previewElements.previewCheckUpdatesButton.addEventListener("click", async () => {
  await checkAppUpdates();
  renderPreviewUpdates();
});

previewElements.updatesPanel.addEventListener("click", (event) => {
  const appButton = event.target.closest("[data-preview-update-app]");
  if (appButton) {
    void updateApp(appButton.dataset.previewUpdateApp).then(renderPreviewUpdates);
    return;
  }
  if (event.target.closest("[data-preview-update-all]")) {
    void updateAllApps().then(renderPreviewUpdates);
  }
});

previewElements.search.addEventListener("input", () => {
  preview.libraryFilter = previewElements.search.value;
  if (preview.libraryFilter) setPreviewView("library");
  applyLibraryFilter();
});

document.addEventListener("keydown", (event) => {
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    previewElements.search.focus();
    previewElements.search.select();
  }
  if (event.key === "Escape" && !previewElements.folderBackdrop.classList.contains("hidden")) {
    closePreviewFolder();
  }
});

// 초기 렌더 전에도 빈 화면이 어색하지 않도록 홈을 먼저 표시합니다.
setPreviewView("home");
